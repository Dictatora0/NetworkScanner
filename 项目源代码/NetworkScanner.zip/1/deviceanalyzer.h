#ifndef DEVICEANALYZER_H
#define DEVICEANALYZER_H

#include <QWidget>
#include <QMap>
#include <QVector>
#include <QPair>
#include <QString>
#include <QtCharts/QChart>
#include <QtCharts/QPieSeries>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QBarCategoryAxis>
#include <QtCharts/QValueAxis>
#include <QtCharts/QChartView>
#include "networkscanner.h"

// 设备分析器类 - 提供对扫描结果的统计分析
/**
 * @class DeviceAnalyzer
 * @brief 设备分析器类 - 提供对扫描结果的统计分析
 */
class DeviceAnalyzer : public QWidget
{
    Q_OBJECT
    
public:
    /**
     * @brief DeviceAnalyzer 构造函数
     * @param parent 父控件指针
     */
    DeviceAnalyzer(QWidget *parent = nullptr);
    
    /**
     * @brief 分析扫描结果并更新统计图表
     * @param hosts 主机信息列表
     */
    void analyzeHosts(const QList<HostInfo> &hosts);
    /**
     * @brief 清除分析结果和图表数据
     */
    void clear();
    
    // 获取各种统计信息
    /**
     * @brief 获取发现的总设备数
     * @return 总设备数
     */
    int getTotalHostsCount() const { return m_totalHosts; }
    /**
     * @brief 获取可访问设备数
     * @return 可访问设备数
     */
    int getReachableHostsCount() const { return m_reachableHosts; }
    /**
     * @brief 获取不可访问设备数
     * @return 不可访问设备数
     */
    int getUnreachableHostsCount() const { return m_totalHosts - m_reachableHosts; }
    
    // 获取各种图表
    /**
     * @brief 获取设备类型分布图表
     * @return 设备类型图表指针
     */
    QChart* getDeviceTypeChart() const { return m_deviceTypeChart; }
    /**
     * @brief 获取端口分布图表
     * @return 端口分布图表指针
     */
    QChart* getPortDistributionChart() const { return m_portDistributionChart; }
    /**
     * @brief 获取设备厂商分布图表
     * @return 设备厂商图表指针
     */
    QChart* getVendorDistributionChart() const { return m_vendorDistributionChart; }
    
    /**
     * @brief 创建安全风险报告
     * @param hosts 主机信息列表
     * @return 安全报告字符串
     */
    QString generateSecurityReport(const QList<HostInfo> &hosts);
    
signals:
    /**
     * @brief 分析完成信号
     */
    void analysisCompleted();
    
private:
    // 扫描统计
    int m_totalHosts;       ///< 发现总设备数
    int m_reachableHosts;   ///< 可访问设备数
    
    // 设备类型分布图表
    QChart *m_deviceTypeChart;      ///< 设备类型图表对象
    QPieSeries *m_deviceTypeSeries; ///< 设备类型饼图系列
    
    // 端口分布图表
    QChart *m_portDistributionChart; ///< 端口分布图表对象
    QBarSeries *m_portSeries;        ///< 端口柱状图系列
    
    // 厂商分布图表
    QChart *m_vendorDistributionChart; ///< 设备厂商图表对象
    QPieSeries *m_vendorSeries;        ///< 设备厂商饼图系列
    
    // 创建各类图表
    /**
     * @brief 创建设备类型图表
     */
    void createDeviceTypeChart();
    /**
     * @brief 创建端口分布图表
     */
    void createPortDistributionChart();
    /**
     * @brief 创建设备厂商分布图表
     */
    void createVendorDistributionChart();
    
    // 设备类型判断
    /**
     * @brief 根据主机信息判断设备类型
     * @param host 主机信息
     * @return 设备类型字符串
     */
    QString determineDeviceType(const HostInfo &host);
};

#endif // DEVICEANALYZER_H 