/**
 * @file scanhistory.h
 * @brief 扫描历史记录和会话管理类的定义
 * @details 提供存储、加载、比较和管理多次网络扫描会话的功能。
 * @author Network Scanner Team
 * @version 2.0.1
 */

#ifndef SCANHISTORY_H
#define SCANHISTORY_H

#include <QObject>
#include <QDateTime>
#include <QList>
#include <QMap>
#include <QString>
#include <QFile>
#include <QTextStream>
#include "networkscanner.h"

/**
 * @struct ScanSession
 * @brief 存储单次扫描会话的信息。
 * @details 包含扫描的日期时间、描述、主机总数以及该会话中发现的所有主机信息。
 */
struct ScanSession {
    QDateTime dateTime;         ///< 扫描会话的日期和时间
    QString description;        ///< 会话描述 (例如，"家庭网络扫描")
    QList<HostInfo> hosts;      ///< 本次扫描发现的主机列表
    int totalHostsScanned;      ///< 本次扫描尝试扫描的主机总数 (可选)
    
    /**
     * @brief ScanSession 默认构造函数。
     * @details 初始化 dateTime 为当前时间，description 为空，totalHostsScanned 为0。
     */
    ScanSession() : dateTime(QDateTime::currentDateTime()), totalHostsScanned(0) {}
    
    /**
     * @brief ScanSession 构造函数。
     * @param desc 会话描述。
     * @param hostList 本次扫描发现的主机列表。
     * @param totalScanned (可选) 本次扫描尝试扫描的总主机数。
     */
    ScanSession(const QString &desc, const QList<HostInfo> &hostList, int totalScanned = 0)
        : dateTime(QDateTime::currentDateTime()), description(desc), 
          hosts(hostList), totalHostsScanned(totalScanned) {}
          
    /**
     * @brief 获取本次会话中发现的主机总数。
     * @return int 主机数量。
     */
    int totalHosts() const { return hosts.size(); }
    int reachableHosts() const;
    int unreachableHosts() const { return totalHosts() - reachableHosts(); }
    QMap<int, int> portDistribution() const;
};

/**
 * @class ScanHistory
 * @brief 扫描历史管理器类。
 * @details 负责存储、加载、管理和比较多次扫描会话。提供会话的增删改查功能，
 *          支持从文件导入/导出历史记录 (例如JSON格式)，并能比较两次会话的差异。
 */
class ScanHistory : public QObject
{
    Q_OBJECT
    
public:
    /**
     * @brief ScanHistory 构造函数。
     * @param parent 父对象指针。
     */
    explicit ScanHistory(QObject *parent = nullptr);
    
    /**
     * @brief 添加一次新的扫描会话到历史记录。
     * @param hosts 本次扫描发现的主机列表。
     * @param description (可选) 会话的描述，默认为当前日期时间。
     * @details 创建一个新的 ScanSession 对象并添加到 m_sessions 列表中。
     *          会触发 historyChanged() 信号。
     */
    void addSession(const QList<HostInfo> &hosts, const QString &description = "");
    
    /**
     * @brief 获取所有存储的扫描会话。
     * @return QList<ScanSession> 包含所有扫描会话的列表。
     */
    QList<ScanSession> getSessions() const;
    
    /**
     * @brief 根据索引获取指定的扫描会话。
     * @param index 会话在列表中的索引。
     * @return ScanSession 指定的扫描会话。如果索引无效，则返回一个空的默认会话。
     */
    ScanSession getSession(int index) const;
    
    /**
     * @brief 获取存储的扫描会话总数。
     * @return int 会话数量。
     */
    int sessionCount() const;
    
    /**
     * @brief 根据索引移除一个扫描会话。
     * @param index 要移除的会话的索引。
     * @return 如果成功移除则返回 true，否则 (例如索引无效) 返回 false。
     * @details 会触发 historyChanged() 信号。
     */
    bool removeSession(int index);
    
    /**
     * @brief 清除所有扫描历史记录。
     * @details 会触发 historyChanged() 信号。
     */
    void clearHistory();
    
    /**
     * @brief 将扫描历史保存到文件 (例如JSON格式)。
     * @param filename 要保存的文件名。
     * @return 如果保存成功则返回 true，否则返回 false。
     */
    bool saveToFile(const QString &filename) const;
    
    /**
     * @brief 从文件加载扫描历史 (例如JSON格式)。
     * @param filename 要加载的文件名。
     * @return 如果加载成功则返回 true，否则返回 false。
     * @details 加载成功后会触发 historyChanged() 信号。
     */
    bool loadFromFile(const QString &filename);
    
    /**
     * @brief 比较两次扫描会话的结果，找出新增和消失的主机。
     * @param index1 第一个会话的索引 (通常是较早的会话)。
     * @param index2 第二个会话的索引 (通常是较新的会话)。
     * @return QPair<QList<HostInfo>, QList<HostInfo>>
     *         - first: 在会话2中出现但未在会话1中出现的主机 (新增主机)。
     *         - second: 在会话1中出现但未在会话2中出现的主机 (消失主机)。
     * @throws std::out_of_range 如果索引无效。
     */
    QPair<QList<HostInfo>, QList<HostInfo>> compareScans(int index1, int index2) const;
    
signals:
    /**
     * @brief 当扫描历史记录发生变化时 (例如添加、删除会话或加载历史) 发出此信号。
     */
    void historyChanged();
    
private:
    QList<ScanSession> m_sessions; ///< 存储所有扫描会话的列表
};

#endif // SCANHISTORY_H 