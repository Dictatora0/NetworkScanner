/**
 * @file networkscanner.cpp
 * @brief 网络扫描器类的实现
 * @details 提供网络设备发现和端口扫描功能的实现
 * @author Network Scanner Team
 * @version 2.1.0
 */

#include "networkscanner.h"
#include <QDebug>
#include <QTime>
#include <QTimer>
#include <QMutexLocker>
#include <QProcess>
#include <QFile>
#include <QTextStream>
#include <QCoreApplication>
#include <QDir>
#include <QRegularExpression>
#include <QNetworkInterface>
#include <QThread>
#include <QEventLoop>
#include <QElapsedTimer>
#include <QMessageBox>
#include <QRandomGenerator>
#include <random>
#include <algorithm>
#include <QSemaphore>
#include <QScopedPointer>

/**
 * @brief NetworkScanner类构造函数
 * @param parent 父对象
 * @details 初始化扫描器参数和线程池。默认扫描常用端口，并设置线程池最大线程数。
 *          初始化ping信号量以控制并发ping操作。
 */
NetworkScanner::NetworkScanner(QObject *parent)
    : QObject(parent), m_isScanning(false), m_scannedHosts(0), m_totalHosts(0),
      m_scanTimeout(500), m_useCustomRange(false), m_scanMode(STANDARD),
      m_debugMode(false), m_randomizeScan(true)
{
    try {
        // 默认扫描常用端口
        m_portsToScan.clear();
        m_portsToScan << 21 << 22 << 23 << 25 << 53 << 80 << 110 << 135 << 139 << 143 << 443 << 445 << 993 << 995 << 1723 << 3306 << 3389 << 5900 << 8080;
        
        // 设置线程池最大线程数，避免创建过多线程
        m_threadPool.setMaxThreadCount(QThread::idealThreadCount());
        
        // 初始化时间记录
        m_lastProgressUpdate = QDateTime::currentDateTime();
        m_pingSemaphore = new QSemaphore(m_maxConcurrentPings);
    } catch (...) {
        qWarning() << "初始化NetworkScanner时发生异常";
        // 确保至少添加一些基本端口
        if (m_portsToScan.isEmpty()) {
            m_portsToScan << 80 << 443 << 22;
        }
    }
}

/**
 * @brief NetworkScanner类析构函数
 * @details 确保停止所有正在进行的扫描，终止所有相关进程 (特别是ping进程)，
 *          并清理所有分配的资源，包括线程池、扫描结果列表和信号量。
 */
NetworkScanner::~NetworkScanner()
{
    // 确保扫描已停止
    if (m_isScanning) {
        stopScan();
        
        // 等待一小段时间，确保停止逻辑完成
        QElapsedTimer timer;
        timer.start();
        while (m_isScanning && timer.elapsed() < 500) {
            QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
        }
    }
    
    // 确保所有ping进程被终止
    qDebug() << "析构时终止所有ping进程(第一轮)";
    terminateAllPingProcesses();
    
    // 确保扫描任务被完全清理
    for (QFuture<void> &future : m_scanFutures) {
        if (future.isRunning()) {
            // 尝试取消任务(尽管QtConcurrent::run创建的任务无法直接取消)
            future.cancel();
        }
    }
    
    // 清空任务列表
    m_scanFutures.clear();
    
    qDebug() << "析构时终止所有ping进程(第二轮)";
    forceKillAllPingProcesses();
    
    // 确保线程池被正确清理
    m_threadPool.clear();
    m_threadPool.waitForDone(500);
    
    // 释放扫描结果
    m_scannedHostsList.clear();
    m_macAddressCache.clear();
    
    // 释放信号量
    if (m_pingSemaphore) {
        // 确保释放所有可能获取的信号量，防止资源泄漏
        for (int i = 0; i < m_maxConcurrentPings * 3; i++) {
            m_pingSemaphore->release();
        }
        delete m_pingSemaphore;
        m_pingSemaphore = nullptr;
    }
    
    // 在退出前最后一次检查并终止任何残留的ping进程
    qDebug() << "析构时终止所有ping进程(最终检查)";
    forceKillAllPingProcesses();
    
    qDebug() << "NetworkScanner析构完成";
}

/**
 * @brief 设置自定义端口扫描列表
 * @param ports 要扫描的端口列表
 * @note 如果扫描正在进行，此设置将无效。
 */
void NetworkScanner::setCustomPortsToScan(const QList<int> &ports)
{
    if (!m_isScanning && !ports.isEmpty()) {
        m_portsToScan = ports;
    }
}

/**
 * @brief 设置扫描超时时间
 * @param msecs 超时时间（毫秒）
 * @note 如果扫描正在进行，此设置将无效。超时值必须大于0。
 */
void NetworkScanner::setScanTimeout(int msecs)
{
    if (!m_isScanning && msecs > 0) {
        m_scanTimeout = msecs;
    }
}

/**
 * @brief 设置自定义IP范围
 * @param startIP 起始IP地址
 * @param endIP 结束IP地址
 * @note 如果扫描正在进行，此设置将无效。如果IP范围无效，会发出 scanError信号。
 */
void NetworkScanner::setCustomIPRange(const QString &startIP, const QString &endIP)
{
    if (!m_isScanning) {
        bool startValid = m_startIPRange.setAddress(startIP);
        bool endValid = m_endIPRange.setAddress(endIP);
        
        if (startValid && endValid) {
            m_useCustomRange = true;
        } else {
            m_useCustomRange = false;
            emit scanError("IP范围设置无效");
        }
    }
}

/**
 * @brief 获取扫描结果
 * @return 扫描到的主机信息列表
 */
QList<HostInfo> NetworkScanner::getScannedHosts() const
{
    return m_scannedHostsList;
}

/**
 * @brief 保存结果到文件
 * @param filename 文件名
 */
void NetworkScanner::saveResultsToFile(const QString &filename) const
{
    QFile file(filename);
    if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QTextStream out(&file);
        
        // 添加保存时间和扫描信息
        out << "# 网络扫描结果\n";
        out << "# 保存时间: " << QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss") << "\n";
        out << "# 扫描主机数: " << m_scannedHostsList.size() << "\n";
        
        int reachableHosts = 0;
        for (const HostInfo &host : m_scannedHostsList) {
            if (host.isReachable) {
                reachableHosts++;
            }
        }
        out << "# 可达主机数: " << reachableHosts << "\n\n";
        
        // 写入CSV标题
        out << "IP地址,主机名,MAC地址,厂商,状态,扫描时间";
        
        // 写入端口列表标题
        for (int port : m_portsToScan) {
            out << ",端口" << port;
        }
        out << "\n";
        
        // 写入每个主机的数据，先写可达主机，再写不可达主机
        // 先将主机分类
        QList<HostInfo> reachableList;
        QList<HostInfo> unreachableList;
        
        for (const HostInfo &host : m_scannedHostsList) {
            if (host.isReachable) {
                reachableList.append(host);
            } else {
                unreachableList.append(host);
            }
        }
        
        // 对可达主机按IP排序
        std::sort(reachableList.begin(), reachableList.end(), 
                 [](const HostInfo &a, const HostInfo &b) {
                     return a.ipAddress < b.ipAddress;
                 });
        
        // 先输出可达主机
        for (const HostInfo &host : reachableList) {
            out << host.ipAddress << ","
                << host.hostName << ","
                << host.macAddress << ","
                << host.macVendor << ","
                << "可达" << ","
                << host.scanTime.toString("yyyy-MM-dd hh:mm:ss");
            
            // 写入端口状态
            for (int port : m_portsToScan) {
                if (host.openPorts.contains(port)) {
                    out << "," << (host.openPorts[port] ? "开放" : "关闭");
                } else {
                    out << ",未扫描";
                }
            }
            out << "\n";
        }
        
        // 再输出不可达主机
        for (const HostInfo &host : unreachableList) {
            out << host.ipAddress << ","
                << host.hostName << ","
                << host.macAddress << ","
                << host.macVendor << ","
                << "不可达" << ","
                << host.scanTime.toString("yyyy-MM-dd hh:mm:ss");
            
            // 写入端口状态
            for (int port : m_portsToScan) {
                out << ",未扫描";
            }
            out << "\n";
        }
        
        file.close();
        qDebug() << "结果已保存到: " << filename;
    } else {
        qDebug() << "无法保存到文件: " << filename << " - " << file.errorString();
    }
}

void NetworkScanner::startScan()
{
    try {
        if (m_isScanning)
            return;

        m_isScanning = true;
        m_scannedHosts = 0;
        m_scannedHostsList.clear();
        m_scanFutures.clear();  // 清除之前的任务
        
        // 重置定时器和状态
        m_scanStartTime.start();
        m_lastProgressUpdate = QDateTime::currentDateTime();
        
        emit scanStarted();
        qDebug() << "开始扫描网络...";

        QList<QHostAddress> addressesToScan;
        
        if (m_useCustomRange) {
            // 使用自定义IP范围
            quint32 startIP = m_startIPRange.toIPv4Address();
            quint32 endIP = m_endIPRange.toIPv4Address();
            
            if (startIP <= endIP) {
                // 限制最大IP数量，根据实际需求调整
                quint32 maxIPs = 100; // 增加到100个，但添加随机化
                m_totalHosts = qMin(maxIPs, endIP - startIP + 1);
                
                // 创建所有可能的IP地址
                QList<quint32> allIPs;
                for (quint32 ip = startIP, count = 0; ip <= endIP && count < maxIPs; ++ip, ++count) {
                    allIPs.append(ip);
                }
                
                // 随机打乱IP顺序，避免顺序扫描
                std::random_device rd;
                std::mt19937 g(rd());
                std::shuffle(allIPs.begin(), allIPs.end(), g);
                
                // 转换为QHostAddress
                for (quint32 ip : allIPs) {
                    addressesToScan << QHostAddress(ip);
                }
            } else {
                qDebug() << "无效的IP范围";
                m_isScanning = false;
                emit scanError("无效的IP范围");
                emit scanFinished();
                return;
            }
        } else {
            // 获取本地网络地址并扫描整个子网
            QList<QHostAddress> networkAddresses = getLocalNetworkAddresses();
            
            if (networkAddresses.isEmpty()) {
                qDebug() << "没有找到可用的网络接口";
                m_isScanning = false;
                emit scanError("没有找到可用的网络接口");
                emit scanFinished();
                return;
            }

            // 计算需要扫描的IP地址总数，每个子网最多扫描50个IP
            const int MAX_IPS_PER_SUBNET = 40; // 降低每个子网扫描的IP数量
            m_totalHosts = 0;
            
            // 为每个网段准备扫描地址
            for (const QHostAddress &network : networkAddresses) {
                QHostAddress baseAddress(network.toIPv4Address() & 0xFFFFFF00);
                
                // 创建子网内的IP列表
                QList<QHostAddress> subnetIPs;
                for (int i = 1; i < 255; ++i) {
                    QHostAddress currentAddress(baseAddress.toIPv4Address() + i);
                    subnetIPs.append(currentAddress);
                }
                
                // 随机打乱子网IP顺序
                std::random_device rd;
                std::mt19937 g(rd());
                std::shuffle(subnetIPs.begin(), subnetIPs.end(), g);
                
                // 取前MAX_IPS_PER_SUBNET个IP
                int count = 0;
                for (const QHostAddress &ip : subnetIPs) {
                    if (count >= MAX_IPS_PER_SUBNET) break;
                    addressesToScan.append(ip);
                    count++;
                }
                
                m_totalHosts += qMin(MAX_IPS_PER_SUBNET, subnetIPs.size());
            }
        }
        
        // 确保不扫描过多IP，限制为150个
        if (addressesToScan.size() > 150) {
            qDebug() << "扫描IP过多，限制为前150个";
            while (addressesToScan.size() > 150) {
                addressesToScan.removeLast();
            }
            m_totalHosts = 150;
        }
        
        qDebug() << "开始扫描" << addressesToScan.size() << "个IP地址...";
        
        // 分批次创建扫描任务，减少瞬时资源占用
        const int BATCH_SIZE = 5; // 每批次处理5个IP
        int totalBatches = (addressesToScan.size() + BATCH_SIZE - 1) / BATCH_SIZE;
        
        for (int batchIndex = 0; batchIndex < totalBatches; batchIndex++) {
            // 计算当前批次的起始和结束索引
            int startIdx = batchIndex * BATCH_SIZE;
            int endIdx = qMin(startIdx + BATCH_SIZE, addressesToScan.size());
            
            // 延迟执行当前批次
            QTimer::singleShot(batchIndex * 500, this, [this, addressesToScan, startIdx, endIdx]() {
                if (!m_isScanning) return;
                
                // 处理该批次中的每个IP
                for (int i = startIdx; i < endIdx; i++) {
                    QHostAddress address = addressesToScan[i];
                    
                    // 每处理2个IP就处理一次事件，保持UI响应
                    if ((i - startIdx) % 2 == 0) {
                        QCoreApplication::processEvents();
                    }
                    
                    // 启动扫描任务
                    QFuture<void> future = QtConcurrent::run([this, address]() {
                        try {
                            if (!m_isScanning) return;
                            scanHost(address);
                        } catch (const std::exception &e) {
                            qWarning() << "扫描主机异常:" << address.toString() << "-" << e.what();
                        } catch (...) {
                            qWarning() << "扫描主机未知异常:" << address.toString();
                        }
                    });
                    
                    QMutexLocker locker(&m_mutex);
                    m_scanFutures.append(future);
                }
            });
        }

        // 在所有批次启动后启动结果处理
        QTimer::singleShot(500, this, &NetworkScanner::processScanResults);
        
        // 添加进度监控定时器，定期更新进度
        QTimer *progressTimer = new QTimer(this);
        connect(progressTimer, &QTimer::timeout, this, [this, progressTimer]() {
            if (!m_isScanning) {
                progressTimer->stop();
                progressTimer->deleteLater();
                return;
            }
            
            // 更新进度
            if (m_totalHosts > 0) {
                int progress = (m_scannedHosts * 100) / m_totalHosts;
                
                // 处理UI事件，确保界面响应
                QCoreApplication::processEvents();
                
                emit scanProgress(progress);
                
                // 记录当前进度
                static int lastProgress = 0;
                static int stuckCount = 0;
                
                if (progress == lastProgress) {
                    stuckCount++;
                    if (stuckCount > 10) { // 如果进度停滞超过10秒
                        qDebug() << "扫描进度停滞在" << progress << "%超过10秒，考虑强制结束";
                        
                        // 如果进度已经很高，则认为扫描基本完成
                        if (progress > 90) {
                            qDebug() << "进度已超过90%，强制完成扫描";
                            // 手动更新未完成的主机状态为不可达
                            int remaining = m_totalHosts - m_scannedHosts;
                            m_scannedHosts = m_totalHosts;
                            emit scanProgress(100);
                            stopScan();
                        }
                    }
                } else {
                    lastProgress = progress;
                    stuckCount = 0;
                }
            }
            
            // 处理UI事件，确保界面响应
            QCoreApplication::processEvents();
        });
        progressTimer->start(1000); // 每秒更新一次进度
        
        // 设置总超时保护
        int maxScanTime = 90000; // 1.5分钟，减少原来的2分钟
        QTimer::singleShot(maxScanTime, this, [this]() {
            if (m_isScanning) {
                qDebug() << "扫描超时，强制结束...";
                stopScan();
                emit scanError("扫描超时，已自动结束");
            }
        });
    } catch (const std::exception &e) {
        qWarning() << "启动扫描时发生异常: " << e.what();
        m_isScanning = false;
        emit scanError("启动扫描时发生异常: " + QString(e.what()));
        emit scanFinished();
    } catch (...) {
        qWarning() << "启动扫描时发生未知异常";
        m_isScanning = false;
        emit scanError("启动扫描时发生未知异常");
        emit scanFinished();
    }
}

void NetworkScanner::stopScan()
{
    if (!m_isScanning)
        return;

    qDebug() << "正在停止扫描...";
    m_isScanning = false;
    
    // 先处理UI事件，确保界面响应
    QCoreApplication::processEvents();
    
    // 立即更新UI，避免用户等待
    emit scanProgress(100); // 强制进度条显示完成
    emit scanFinished();    // 提前发送完成信号，让UI可以立即响应
    
    // 立即强制终止所有ping进程
    qDebug() << "停止扫描: 第一轮终止ping进程";
    terminateAllPingProcesses();
    
    // 再次使用强制方法确保清理彻底
    qDebug() << "停止扫描: 第二轮强制终止ping进程";
    forceKillAllPingProcesses();
    
    // 处理UI事件，确保界面响应
    QCoreApplication::processEvents();
    
    // 强制重置信号量，确保没有任何线程被阻塞
    if (m_pingSemaphore) {
        // 先释放所有信号量，防止任何线程被阻塞
        for (int i = 0; i < m_maxConcurrentPings * 3; i++) {
            m_pingSemaphore->release();
        }
        delete m_pingSemaphore;
        m_pingSemaphore = new QSemaphore(m_maxConcurrentPings);
    }
    
    // 清理线程池，取消所有未完成的任务
    m_threadPool.clear();
    m_threadPool.waitForDone(200);
    
    // 尝试取消或废弃所有扫描任务
    {
        QMutexLocker locker(&m_mutex);
        for (QFuture<void> &future : m_scanFutures) {
            if (future.isRunning()) {
                // 尝试取消任务(尽管QtConcurrent::run创建的任务无法直接取消)
                future.cancel();
            }
        }
        
        // 清空扫描队列
        m_scanFutures.clear();
    }
    
    // 处理UI事件，确保界面响应
    QCoreApplication::processEvents();
    
    // 记录扫描统计信息
    int scanDuration = m_scanStartTime.elapsed() / 1000; // 秒
    int hostsFound = m_scannedHostsList.size();
    int reachableHosts = 0;
    
    for (const HostInfo &host : m_scannedHostsList) {
        if (host.isReachable) {
            reachableHosts++;
        }
    }
    
    qDebug() << "扫描统计: 耗时" << scanDuration << "秒, 扫描" 
             << m_scannedHosts << "个主机, 发现" << hostsFound 
             << "个主机, 其中" << reachableHosts << "个可达";
    
    // 最终清理 - 使用立即执行而非延时，避免遗漏
    // 最后一次检查并终止任何残留进程
    qDebug() << "停止扫描: 最终进程清理";
    terminateAllPingProcesses();
    forceKillAllPingProcesses();

    // 在macOS上进行最终验证
#ifdef Q_OS_MACOS
    QProcess checkProcess;
    checkProcess.start("pgrep", QStringList() << "ping");
    checkProcess.waitForFinished(200);
    QString output = QString::fromLocal8Bit(checkProcess.readAllStandardOutput()).trimmed();
    if (!output.isEmpty()) {
        QStringList pids = output.split('\n', Qt::SkipEmptyParts);
        qDebug() << "警告: 清理后仍有" << pids.size() << "个ping进程存在";
        
        // 最后再尝试一次强制终止
        system("killall -9 ping 2>/dev/null || true");
        
        // 如果仍有残留进程，尝试单个终止
        QThread::msleep(50);
        QProcess finalCheck;
        finalCheck.start("pgrep", QStringList() << "ping");
        if (finalCheck.waitForFinished(200)) {
            QString finalOutput = QString::fromLocal8Bit(finalCheck.readAllStandardOutput()).trimmed();
            if (!finalOutput.isEmpty()) {
                QStringList finalPids = finalOutput.split('\n', Qt::SkipEmptyParts);
                for (const QString &pid : finalPids) {
                    system(QString("kill -9 %1 2>/dev/null || true").arg(pid).toStdString().c_str());
                }
            }
        }
    } else {
        qDebug() << "所有ping进程已清理完毕";
    }
#endif
    
    // 确保所有动态分配的对象都被释放
    QCoreApplication::processEvents();
}

bool NetworkScanner::isScanning() const
{
    return m_isScanning;
}

QList<QHostAddress> NetworkScanner::getLocalNetworkAddresses()
{
    QList<QHostAddress> result;
    
    // 获取所有网络接口
    QList<QNetworkInterface> interfaces = QNetworkInterface::allInterfaces();
    
    for (const QNetworkInterface &interface : interfaces) {
        // 跳过不活动或环回接口
        if (!(interface.flags() & QNetworkInterface::IsUp) || 
            (interface.flags() & QNetworkInterface::IsLoopBack)) {
            continue;
        }
        
        // 获取该接口的所有IP地址
        QList<QNetworkAddressEntry> entries = interface.addressEntries();
        for (const QNetworkAddressEntry &entry : entries) {
            QHostAddress address = entry.ip();
            // 只处理IPv4地址
            if (address.protocol() == QAbstractSocket::IPv4Protocol) {
                result.append(address);
            }
        }
    }
    
    return result;
}

void NetworkScanner::scanHost(const QHostAddress &address)
{
    try {
        if (!m_isScanning) return;
        
        HostInfo hostInfo;
        hostInfo.ipAddress = address.toString();
        hostInfo.scanTime = QDateTime::currentDateTime();
        
        QElapsedTimer timer;
        timer.start();
        
        // 使用新的pingHost方法进行主机可达性检测
        hostInfo.isReachable = pingHost(address.toString(), m_scanTimeout + 300); // ping超时设为扫描超时+300ms缓冲
        
        int responseTime = timer.elapsed();
        if (m_debugMode || hostInfo.isReachable) { // 仅在调试模式或主机可达时输出
            qDebug() << "Host:" << address.toString() << "Reachable:" << hostInfo.isReachable 
                     << "Response time:" << responseTime << "ms";
        }
        
        hostInfo.hostName = address.toString();
        hostInfo.macAddress = generatePseudoMACFromIP(address.toString());
        hostInfo.macVendor = lookupMacVendor(hostInfo.macAddress);
        
        if (hostInfo.isReachable) {
            try {
                scanHostPorts(hostInfo);
            } catch (const std::exception &e) {
                qDebug() << "端口扫描异常: " << address.toString() << " - " << e.what();
            } catch (...) {
                qDebug() << "端口扫描未知异常: " << address.toString();
            }
        } else {
            for (int port : m_portsToScan) {
                hostInfo.openPorts[port] = false;
            }
        }
        
        {
            QMutexLocker locker(&m_mutex);
            m_scannedHostsList.append(hostInfo);
            emit hostFound(hostInfo);
        }
        
        {
            QMutexLocker locker(&m_mutex);
            m_scannedHosts++;
             // 进度更新逻辑移至processScanResults或专用定时器，此处不再直接更新UI
        }
    } catch (const std::exception &e) {
        qWarning() << "扫描主机时发生异常: " << address.toString() << " - " << e.what();
    } catch (...) {
        qWarning() << "扫描主机时发生未知异常: " << address.toString();
    }
}

bool NetworkScanner::pingHost(const QString& ipAddress, int timeoutMs)
{
    if (!m_isScanning) {
        return false;
    }

    // 在获取信号量前先检查是否仍在扫描
    if (!m_pingSemaphore->tryAcquire(1, 300)) { // 进一步减少等待时间到300ms
        qDebug() << "无法获取ping信号量，跳过:" << ipAddress;
        return false; // 无法获取信号量，放弃此次ping
    }

    // 使用局部变量标记处理结果，确保在任何情况下都释放信号量
    bool isReachable = false;
    
    // 使用智能指针管理QProcess，确保自动释放资源
    QScopedPointer<QProcess> pingProcess(new QProcess());

    try {
        // 设置自动删除属性，避免内存泄漏
        pingProcess->setParent(this);
        
        // 设置进程环境和选项
        pingProcess->setProcessChannelMode(QProcess::MergedChannels); // 合并标准输出和错误
        
        // 设置更短的超时时间，避免长时间阻塞
        int waitTime = qMin(timeoutMs, 300); // 最多等待300毫秒
        
        // 准备ping命令参数 - 使用更短的超时
#ifdef Q_OS_WIN
        QStringList arguments;
        arguments << "-n" << "1" << "-w" << QString::number(waitTime) << ipAddress;
#elif defined(Q_OS_MACOS)
        // macOS特定的ping参数，直接使用超时
        QStringList arguments;
        arguments << "-c" << "1" << "-t" << "1" << "-W" << "300" << ipAddress;
#else
        // 对于Linux
        QStringList arguments;
        arguments << "-c" << "1" << "-W" << "1" << ipAddress;
#endif

        // 使用同步方式运行进程，避免事件循环问题
        pingProcess->start("ping", arguments);
        
        // 获取进程ID，用于日志
        qint64 pingProcessId = pingProcess->processId();
        
        // 等待进程完成，最多等待waitTime毫秒
        if (pingProcess->waitForStarted(waitTime) && pingProcess->waitForFinished(waitTime)) {
            // 如果进程正常退出且返回码为0，则主机可达
            if (pingProcess->exitCode() == 0) {
                isReachable = true;
            }
        } else {
            // 进程未在指定时间内完成，强制终止
            if (m_debugMode) {
                qDebug() << "Ping超时或启动失败:" << ipAddress << "，PID:" << pingProcessId;
            }
            
            // 读取所有可能的输出，避免缓冲区阻塞
            pingProcess->readAll();
            
            // 终止进程
            if (pingProcess->state() != QProcess::NotRunning) {
                pingProcess->terminate();
                if (!pingProcess->waitForFinished(100)) {
                    pingProcess->kill();
                }
            }
        }
        
        // 使用系统命令确保进程被终止（根据进程ID）
        if (pingProcessId > 0) {
#ifdef Q_OS_MACOS
            QString killCmd = QString("kill -9 %1 2>/dev/null || true").arg(pingProcessId);
            system(killCmd.toStdString().c_str());
#elif defined(Q_OS_WIN)
            QString killCmd = QString("taskkill /F /PID %1 /T > nul 2>&1").arg(pingProcessId);
            system(killCmd.toStdString().c_str());
#else
            QString killCmd = QString("kill -9 %1 2>/dev/null || true").arg(pingProcessId);
            system(killCmd.toStdString().c_str());
#endif
        }
    }
    catch (const std::exception& e) {
        qDebug() << "Ping过程发生异常:" << ipAddress << e.what();
    }
    catch (...) {
        qDebug() << "Ping过程发生未知异常:" << ipAddress;
    }

    // 确保释放进程资源
    if (!pingProcess.isNull() && pingProcess->state() != QProcess::NotRunning) {
        pingProcess->kill();
        pingProcess->waitForFinished(50);
    }
    
    // 确保释放信号量
    m_pingSemaphore->release();
    
    return isReachable;
}

void NetworkScanner::scanHostPorts(HostInfo &hostInfo)
{
    // 端口扫描结果
    QMap<int, bool> portResults;
    
    // 使用更短的超时策略
    int baseTimeout = qMin(m_scanTimeout, 200); // 限制最大超时为200ms，减少阻塞时间
    
    // 创建一个QList存储所有socket指针，便于资源管理
    QList<QTcpSocket*> sockets;
    
    try {
        // 仅检查部分常用端口，减少扫描负担
        QList<int> portsToScan;
        if (m_portsToScan.size() > 10) {
            // 如果端口列表过长，只选择前10个最常用的端口
            portsToScan << 80 << 443 << 22 << 21 << 25 << 3389 << 8080 << 445 << 139 << 135;
        } else {
            portsToScan = m_portsToScan;
        }
        
        // 首先尝试连接到所有端口
        for (int port : portsToScan) {
            QTcpSocket* socket = new QTcpSocket();
            sockets.append(socket);
            
            // 设置更短的超时，避免阻塞
            QTimer::singleShot(baseTimeout + 50, socket, &QTcpSocket::disconnectFromHost);
            
            // 连接到主机
            socket->connectToHost(QHostAddress(hostInfo.ipAddress), port);
            
            // 暂时将结果标记为未知
            portResults[port] = false;
            
            // 每创建3个socket就处理一次事件，保持UI响应
            if (sockets.size() % 3 == 0) {
                QCoreApplication::processEvents();
            }
        }
        
        // 给予足够时间让连接建立
        QElapsedTimer timer;
        timer.start();
        
        // 使用更短的总超时时间
        const int TOTAL_PORT_SCAN_TIMEOUT = 300; // 300毫秒总超时
        
        // 检查每个socket的状态
        for (int i = 0; i < sockets.size(); ++i) {
            QTcpSocket* socket = sockets[i];
            int port = portsToScan[i];
            
            // 检查总扫描时间，避免长时间阻塞
            if (timer.elapsed() > TOTAL_PORT_SCAN_TIMEOUT) {
                qDebug() << "端口扫描总时间超过" << TOTAL_PORT_SCAN_TIMEOUT << "ms，提前结束";
                break;
            }
            
            // 处理UI事件，确保响应
            QCoreApplication::processEvents();
            
            // 如果socket已连接，标记端口为开放
            if (socket->state() == QAbstractSocket::ConnectedState) {
                portResults[port] = true;
                socket->disconnectFromHost();
                continue;
            }
            
            // 给不同端口设置不同的超时时间，但整体更短
            int adjustedTimeout = qMin(baseTimeout * (0.6 + 0.4 * QRandomGenerator::global()->generateDouble()), 150.0);
            
            // 只为最常用端口提供稍长超时
            if (port == 80 || port == 443 || port == 22) {
                adjustedTimeout = qMin(200, baseTimeout);
            }
            
            // 等待连接或超时
            if (socket->waitForConnected(adjustedTimeout)) {
                portResults[port] = true;
            } else {
                portResults[port] = false;
            }
            
            // 断开连接
            socket->disconnectFromHost();
            
            // 如果扫描已经停止，立即退出循环
            if (!m_isScanning) {
                qDebug() << "扫描已停止，中断端口扫描";
                break;
            }
        }
        
        // 记录扫描信息
        int connectedPorts = 0;
        for (bool isOpen : portResults.values()) {
            if (isOpen) connectedPorts++;
        }
        
        qDebug() << "IP" << hostInfo.ipAddress << "发现" << connectedPorts 
                 << "个开放端口，耗时" << timer.elapsed() << "毫秒";
    } catch (const std::exception &e) {
        qWarning() << "端口扫描异常: " << hostInfo.ipAddress << " - " << e.what();
    } catch (...) {
        qWarning() << "端口扫描未知异常: " << hostInfo.ipAddress;
    }
    
    // 清理所有socket资源
    for (QTcpSocket* socket : sockets) {
        if (socket->state() != QAbstractSocket::UnconnectedState) {
            socket->abort(); // 强制关闭任何可能仍在连接的socket
        }
        delete socket; // 直接删除，而不是使用deleteLater，避免延迟释放
    }
    sockets.clear();
    
    // 处理UI事件，确保响应
    QCoreApplication::processEvents();
    
    // 更新主机信息
    hostInfo.openPorts = portResults;
}

QString NetworkScanner::lookupHostName(const QHostAddress &address)
{
    QHostInfo hostInfo = QHostInfo::fromName(address.toString());
    if (hostInfo.error() == QHostInfo::NoError && !hostInfo.hostName().isEmpty()) {
        return hostInfo.hostName();
    }
    return "未知主机";
}

QString NetworkScanner::lookupMacAddress(const QHostAddress &address)
{
    QString ip = address.toString();
    
    // 如果缓存中存在，使用缓存的值
    if (m_macAddressCache.contains(ip)) {
        return m_macAddressCache[ip];
    }
    
    // 不再尝试ARP或其他命令，直接生成伪MAC
    QString macAddress = generatePseudoMACFromIP(ip);
    
    // 添加到缓存
    m_macAddressCache.insert(ip, macAddress);
    
    return macAddress;
}

QString NetworkScanner::lookupMacVendor(const QString &macAddress)
{
    if (macAddress.isEmpty() || macAddress == "未知") {
        return "未知";
    }
    
    // 检查是否是模拟MAC地址
    if (macAddress.startsWith("SM:")) {
        return "[模拟] 本地网络";
    }
    
    // 只获取MAC地址的前6位作为OUI (厂商标识符)
    // 确保处理格式为12:34:56:78:9A:BC的MAC地址
    QString oui;
    if (macAddress.contains(":")) {
        QStringList parts = macAddress.split(":");
        if (parts.size() >= 3) {
            oui = parts[0] + parts[1] + parts[2];
        }
    } else {
        // 如果格式不包含冒号，直接取前6个字符
        oui = macAddress.left(6);
    }
    
    // 如果没能提取OUI，则返回未知
    if (oui.isEmpty() || oui.length() < 6) {
        return "未知厂商";
    }
    
    // 常见厂商的简单查找表 - 扩展更多厂商
    static QMap<QString, QString> vendorMap = {
        {"000C29", "VMware"},
        {"000569", "VMware"},
        {"001C42", "微软"},
        {"001DD8", "微软"},
        {"6045BD", "微软"},
        {"3497F6", "微软"},
        {"B83861", "微软"},
        {"2C338F", "苹果"},
        {"3035AD", "苹果"},
        {"48D705", "苹果"},
        {"98E0D9", "苹果"},
        {"B418D1", "苹果"},
        {"C8B5B7", "苹果"},
        {"DC2B2A", "苹果"},
        {"F40F24", "苹果"},
        {"F82793", "苹果"},
        {"0025B3", "戴尔"},
        {"00D04D", "戴尔"},
        {"001B21", "戴尔"},
        {"B8AC6F", "戴尔"},
        {"000D93", "联想"},
        {"001AA0", "联想"},
        {"60EB69", "联想"},
        {"E02CB2", "联想"},
        {"0018FE", "华硕"},
        {"485B39", "华硕"},
        {"00034B", "西门子"},
        {"000E8C", "西门子"},
        {"001D67", "思科"},
        {"0021A0", "思科"},
        {"5475D0", "思科"},
        {"5CDA6F", "思科"},
        {"00E0FC", "华为"},
        {"04BD88", "华为"},
        {"04F938", "华为"},
        {"283CE4", "华为"},
        {"2C9D1E", "华为"},
        {"48435A", "华为"},
        {"70723C", "华为"},
        {"78D752", "华为"},
        {"0019E3", "小米"},
        {"20A783", "小米"},
        {"5C7CD9", "小米"},
        {"640980", "小米"},
        {"9445CE", "小米"},
        {"001AE9", "H3C"},
        {"002389", "H3C"},
        {"00256E", "H3C"},
        {"002593", "TP-Link"},
        {"0C4B54", "TP-Link"},
        {"547595", "TP-Link"},
        {"885FB0", "TP-Link"},
        {"B07FB9", "德赛西威"},
        {"001FDC", "联想"},
        {"88A084", "华硕"},
        {"001479", "美国无线标准协会"},
        // 新增厂商
        {"D89695", "NVIDIA"},
        {"FCA13E", "三星电子"},
        {"D48F33", "三星电子"},
        {"34AA99", "诺基亚"},
        {"001F6B", "LG电子"},
        {"E48F34", "飞利浦"},
        {"0022B0", "D-Link"},
        {"0013F7", "WAGO"},
        {"0080C2", "IEEE 802.1标准协会"},
        {"000E6A", "3Com"},
        {"001292", "惠普"},
        {"001871", "惠普"},
        {"002264", "惠普"},
        {"24BE05", "惠普"},
        {"001083", "IBM"},
        {"000D60", "IBM"},
        {"00FDD8", "SEIKO"},
        {"000BA3", "施耐德电气"},
        {"00079F", "施耐德电气"},
        {"00049F", "飞塔"}
    };
    
    // 转换OUI为大写进行匹配
    QString ouiUpper = oui.toUpper();
    
    // 尝试查找厂商
    if (vendorMap.contains(ouiUpper)) {
        if (m_debugMode) {
            qDebug() << "MAC地址" << macAddress << "OUI为" << ouiUpper << "匹配厂商:" << vendorMap[ouiUpper];
        }
        return vendorMap[ouiUpper];
    }
    
    // 如果没找到，则返回"未知厂商"并标记OUI
    if (m_debugMode) {
        qDebug() << "MAC地址" << macAddress << "OUI为" << ouiUpper << "未找到对应厂商";
    }
    return QString("未知厂商 (%1)").arg(ouiUpper);
}

void NetworkScanner::processScanResults()
{
    if (!m_isScanning) return;
    
    // 先处理UI事件，确保界面响应
    QCoreApplication::processEvents();
    
    static int stuckCounter = 0;
    static int lastScannedHosts = 0;
    static int lastProgress = 0;
    
    // 检查扫描是否已经完成
    bool allFinished = true;
    int activeThreads = 0;
    int completedThreads = 0;
    
    // 遍历所有扫描任务
    QMutexLocker futureLock(&m_mutex);
    QList<QFuture<void>> futures = m_scanFutures; // 复制一份避免遍历时修改
    futureLock.unlock();
    
    for (const QFuture<void> &future : futures) {
        if (future.isStarted()) {
            if (future.isFinished()) {
                completedThreads++;
            } else {
                allFinished = false;
                activeThreads++;
            }
        }
    }
    
    // 更新扫描进度 - 这是从scanHost方法移过来的逻辑
    int currentProgress = 0;
    {
        QMutexLocker locker(&m_mutex);
        if (m_totalHosts > 0) {
            currentProgress = (m_scannedHosts * 100) / m_totalHosts;
            
            // 防止进度条卡住，如果已经超过95%且卡住超过3秒，强制推进到100%
            if (currentProgress >= 95 && currentProgress == lastProgress && stuckCounter >= 3) {
                qDebug() << "强制推进: 进度" << currentProgress << "%卡住" << stuckCounter << "秒，强制完成";
                currentProgress = 100;
                m_scannedHosts = m_totalHosts;
            }
            
            // 更新UI进度 - 使用更少的更新频率，减少UI阻塞
            if (currentProgress != lastProgress) {
                // 增加事件处理，确保UI响应
                QCoreApplication::processEvents();
                emit scanProgress(currentProgress);
                lastProgress = currentProgress;
            }
            
            // 检查是否完成
            if (m_scannedHosts >= m_totalHosts || currentProgress >= 100) {
                if (m_isScanning) {
                    qDebug() << "所有主机已扫描完成，结束扫描";
                    m_isScanning = false;
                    
                    // 发送UI信号
                    emit scanProgress(100);
                    
                    // 立即强制终止所有残留进程
                    qDebug() << "扫描完成: 强制终止所有进程";
                    terminateAllPingProcesses();
                    forceKillAllPingProcesses();
                    
                    // 清理资源并结束扫描
                    emit scanFinished();
                    
                    // 再次进行终端检查
                    QTimer::singleShot(200, this, [this]() {
                        forceKillAllPingProcesses();
                        // 再次处理事件，确保UI响应
                        QCoreApplication::processEvents();
                    });
                    
                    return;
                }
            }
        }
    }
    
    // 检查是否已经超时
    int elapsedSeconds = m_scanStartTime.elapsed() / 1000;
    bool timeoutReached = elapsedSeconds > 60; // 减少到1分钟超时
    
    // 检测进度是否停滞
    bool progressStuck = false;
    {
        QMutexLocker locker(&m_mutex);
        if (m_scannedHosts == lastScannedHosts && m_scannedHosts > 0) {
            stuckCounter++;
            if (stuckCounter >= 5) { // 减少到5秒无进展视为卡死
                progressStuck = true;
                qDebug() << "扫描进度停滞" << stuckCounter << "秒，可能卡死";
                
                // 如果进度已经超过90%，自动完成扫描
                if (currentProgress > 90) {
                    qDebug() << "进度已达" << currentProgress << "%且卡死，自动完成扫描";
                    m_scannedHosts = m_totalHosts;  // 强制设置为完成
                    emit scanProgress(100);
                    
                    // 立即强制终止所有残留进程
                    m_isScanning = false;
                    qDebug() << "卡死自动完成: 强制终止所有进程";
                    terminateAllPingProcesses();
                    forceKillAllPingProcesses();
                    
                    // 清理资源并结束扫描
                    emit scanFinished();
                    
                    // 再次进行终端检查
                    QTimer::singleShot(200, this, [this]() {
                        forceKillAllPingProcesses();
                        QCoreApplication::processEvents();
                    });
                    
                    return;
                }
            }
        } else {
            stuckCounter = 0;
            lastScannedHosts = m_scannedHosts;
        }
    }
    
    // 如果扫描进度超过90%且超过20秒，也视为超时（提前认为完成）
    bool progressTimeout = false;
    {
        QMutexLocker locker(&m_mutex);
        if (m_totalHosts > 0 && m_scannedHosts > 0) {
            int progress = (m_scannedHosts * 100) / m_totalHosts;
            if (progress > 90 && elapsedSeconds > 20) {
                progressTimeout = true;
                qDebug() << "扫描进度已达" << progress << "%且超过20秒，认为完成";
                
                // 自动完成扫描
                m_scannedHosts = m_totalHosts;  // 强制设置为完成
                emit scanProgress(100);
                
                // 立即强制终止所有残留进程
                m_isScanning = false;
                qDebug() << "超时自动完成: 强制终止所有进程";
                terminateAllPingProcesses();
                forceKillAllPingProcesses();
                
                // 清理资源并结束扫描
                emit scanFinished();
                
                // 再次进行终端检查
                QTimer::singleShot(200, this, [this]() {
                    forceKillAllPingProcesses();
                    QCoreApplication::processEvents();
                });
                
                return;
            }
        }
    }
    
    // 更新状态日志（每5秒一次，避免过多输出）
    QDateTime now = QDateTime::currentDateTime();
    if (m_lastProgressUpdate.secsTo(now) >= 5) {
        m_lastProgressUpdate = now;
        qDebug() << "扫描状态: 已完成" << completedThreads << "个任务, 活跃" 
                 << activeThreads << "个任务, 已扫描" 
                 << m_scannedHosts << "/" << m_totalHosts << "个主机, 耗时" << elapsedSeconds << "秒";
                 
        // 显示更详细的进度信息，帮助排查卡死问题
        qDebug() << "进度详情: 当前" << currentProgress << "%, 卡住计数器:" << stuckCounter 
                 << ", 超时判断:" << (timeoutReached ? "是" : "否") 
                 << ", 进度停滞:" << (progressStuck ? "是" : "否");
    }
    
    // 如果检测到卡死或者超时，强制终止扫描
    if ((progressStuck && stuckCounter >= 10) || (timeoutReached && currentProgress > 50)) {
        qDebug() << "检测到扫描卡死或超时，强制终止";
        
        // 标记为完成
        {
            QMutexLocker locker(&m_mutex);
            m_scannedHosts = m_totalHosts;
        }
        
        // 发送UI信号
        emit scanProgress(100);
        
        // 终止扫描
        m_isScanning = false;
        qDebug() << "强制终止: 清理所有进程";
        terminateAllPingProcesses();
        forceKillAllPingProcesses();
        
        // 清理资源并结束扫描
        emit scanFinished();
        
        return;
    }
    
    // 如果所有任务都已完成，但扫描标志仍为true，说明可能有漏掉的结果
    if (allFinished && m_isScanning && activeThreads == 0 && m_scannedHosts < m_totalHosts) {
        qDebug() << "所有任务已完成，但扫描数量不符，强制完成: 已扫描" 
                 << m_scannedHosts << "/" << m_totalHosts;
                 
        // 标记为完成
        {
            QMutexLocker locker(&m_mutex);
            m_scannedHosts = m_totalHosts;
        }
        
        // 发送UI信号
        emit scanProgress(100);
        
        // 终止扫描
        m_isScanning = false;
        qDebug() << "强制完成: 清理所有进程";
        terminateAllPingProcesses();
        forceKillAllPingProcesses();
        
        // 清理资源并结束扫描
        emit scanFinished();
        
        return;
    }
    
    // 如果扫描仍在继续，安排下一次检查
    if (m_isScanning) {
        // 根据进度和卡死情况调整检查频率
        int nextCheckDelay = 1000; // 默认1秒
        
        if (stuckCounter > 0 || currentProgress > 90) {
            // 如果有卡死迹象或接近完成，更频繁地检查
            nextCheckDelay = 300;
        }
        
        // 处理当前事件队列中的事件，提高UI响应性
        QCoreApplication::processEvents();
        
        QTimer::singleShot(nextCheckDelay, this, &NetworkScanner::processScanResults);
    }
}

// 添加一个专门用于终止所有ping进程的辅助方法
/**
 * @brief 终止所有正在运行的ping进程 (尝试优雅终止)。
 * @details 此方法会根据操作系统使用不同的命令 (pkill, taskkill) 来终止名为 "ping" 的进程。
 *          在macOS上，会多次尝试并验证终止效果。也会尝试释放所有ping信号量。
 */
void NetworkScanner::terminateAllPingProcesses()
{
    // 强制结束任何可能仍在运行的进程
    qDebug() << "正在终止所有ping进程...";
    
    // 在macOS上，使用特殊命令确保ping进程彻底终止
#ifdef Q_OS_MACOS
    // 先使用pkill尝试优雅终止
    QProcess killProcess;
    killProcess.start("pkill", QStringList() << "ping");
    killProcess.waitForFinished(500);
    
    // 再使用强制终止确保完全清理
    QProcess forceKillProcess;
    forceKillProcess.start("pkill", QStringList() << "-9" << "ping");
    forceKillProcess.waitForFinished(500);
    
    // 再使用pgrep确认是否还有ping进程
    QProcess checkProcess;
    checkProcess.start("pgrep", QStringList() << "ping");
    checkProcess.waitForFinished(500);
    QString output = QString::fromLocal8Bit(checkProcess.readAllStandardOutput()).trimmed();
    if (!output.isEmpty()) {
        QStringList pids = output.split('\n');
        qDebug() << "仍有" << pids.size() << "个ping进程存在，尝试单独终止";
        
        for (const QString &pid : pids) {
            bool ok;
            qint64 pidNum = pid.toLongLong(&ok);
            if (ok && pidNum > 0) {
                QProcess killSingleProcess;
                killSingleProcess.start("kill", QStringList() << "-9" << pid);
                killSingleProcess.waitForFinished(100);
            }
        }
    }
#elif defined(Q_OS_WIN)
    // Windows版本的进程终止
    QProcess killProcess;
    killProcess.start("taskkill", QStringList() << "/F" << "/IM" << "ping.exe");
    killProcess.waitForFinished(1000);
    
    // 再执行一次确保彻底终止
    QProcess forceKillProcess;
    forceKillProcess.start("taskkill", QStringList() << "/F" << "/IM" << "ping.exe" << "/T");
    forceKillProcess.waitForFinished(500);
#else
    // Linux版本的进程终止
    QProcess killProcess;
    killProcess.start("pkill", QStringList() << "-9" << "ping");
    killProcess.waitForFinished(1000);
#endif
    
    // 尝试释放所有ping信号量，防止有阻塞的获取操作
    if (m_pingSemaphore) {
        for (int i = 0; i < m_maxConcurrentPings * 3; i++) {
            m_pingSemaphore->release();
        }
    }
    
    // 再次检查确认所有ping进程都已终止
    QThread::msleep(50);
    
#ifdef Q_OS_MACOS
    // 最后一次检查
    QProcess finalCheck;
    finalCheck.start("pgrep", QStringList() << "ping");
    finalCheck.waitForFinished(500);
    QString finalOutput = QString::fromLocal8Bit(finalCheck.readAllStandardOutput()).trimmed();
    if (!finalOutput.isEmpty()) {
        QStringList finalPids = finalOutput.split('\n');
        qDebug() << "最终检查仍有" << finalPids.size() << "个ping进程存在，使用系统命令强制终止";
        system("killall -9 ping 2>/dev/null");
    }
#endif
    
    qDebug() << "ping进程终止操作完成";
}

// 添加一个辅助方法用于规范化MAC地址格式
/**
 * @brief 将MAC地址字符串规范化为大写的 "XX:XX:XX:XX:XX:XX" 格式。
 * @param macAddress 原始MAC地址字符串，可以包含":"或"-"作为分隔符，或无分隔符。
 * @return 规范化后的MAC地址。如果输入无效或无法规范化，则返回 "未知"。
 */
QString NetworkScanner::normalizeMacAddress(const QString &macAddress)
{
    if (macAddress.isEmpty() || macAddress == "未知") {
        return macAddress;
    }
    
    QString rawMac = macAddress.trimmed();
    QStringList parts;
    
    // 检查MAC地址分隔符（: 或 -）
    if (rawMac.contains(':')) {
        parts = rawMac.split(':');
    } else if (rawMac.contains('-')) {
        parts = rawMac.split('-');
    } else {
        // 如果没有分隔符，尝试每两个字符分割
        for (int i = 0; i < rawMac.length(); i += 2) {
            if (i + 2 <= rawMac.length()) {
                parts << rawMac.mid(i, 2);
            } else {
                parts << rawMac.mid(i, 1);
            }
        }
    }
    
    // 确保每部分都是两位数（补前导零）
    for (int i = 0; i < parts.size(); ++i) {
        if (parts[i].length() == 1) {
            parts[i] = "0" + parts[i];
        }
    }
    
    // 如果检测到部分长度不对，尝试修复
    if (parts.size() != 6) {
        // 如果部分数量小于6，可能是因为某些段是单个字符
        QString tempMac = rawMac.replace(":", "").replace("-", "");
        parts.clear();
        
        // 确保MAC地址有12个十六进制字符（6段，每段2个字符）
        if (tempMac.length() <= 12) {
            for (int i = 0; i < tempMac.length(); i += 2) {
                if (i + 2 <= tempMac.length()) {
                    parts << tempMac.mid(i, 2);
                } else if (i + 1 <= tempMac.length()) {
                    parts << "0" + tempMac.mid(i, 1);
                }
            }
            
            // 如果还是不足6段，补充未知段
            while (parts.size() < 6) {
                parts << "00";
            }
        }
    }
    
    // 最终组合成标准格式
    QString normalizedMac = parts.join(":").toUpper();
    
    // 验证是否是合法的MAC地址
    QRegularExpression validMac("^([0-9A-F]{2}[:]){5}([0-9A-F]{2})$");
    if (!validMac.match(normalizedMac).hasMatch()) {
        qDebug() << "无法规范化MAC地址格式: " << rawMac << " -> " << normalizedMac;
        return "未知";
    }
    
    return normalizedMac;
}

// 修改ARP扫描方法
/**
 * @brief 执行ARP扫描以获取本地网络接口的MAC地址及其子网内一些IP的伪MAC。
 * @return IP地址 (QHostAddress) 和 MAC地址 (QString) 对的列表。
 * @details 此方法不再执行外部arp命令。它会遍历所有活动的网络接口，
 *          获取接口本身的MAC地址，并为其IP地址（如果尚未在缓存中）创建条目。
 *          同时，会为每个接口所在子网内的一些IP地址生成伪MAC地址并添加到结果中。
 *          所有获取或生成的MAC地址都会存入 m_macAddressCache。
 */
QList<QPair<QHostAddress, QString>> NetworkScanner::performARPScan()
{
    QList<QPair<QHostAddress, QString>> arpResults;
    
    try {
        // 不再执行arp命令，直接通过QNetworkInterface获取本地接口信息
        QList<QNetworkInterface> interfaces = QNetworkInterface::allInterfaces();
        for (const QNetworkInterface &interface : interfaces) {
            if (interface.flags() & QNetworkInterface::IsUp && 
                !(interface.flags() & QNetworkInterface::IsLoopBack)) {
                QString hwMac = normalizeMacAddress(interface.hardwareAddress()).toUpper();
                if (!hwMac.isEmpty() && hwMac != "00:00:00:00:00:00") {
                    QList<QNetworkAddressEntry> entries = interface.addressEntries();
                    for (const QNetworkAddressEntry &entry : entries) {
                        if (entry.ip().protocol() == QAbstractSocket::IPv4Protocol) {
                            if (!m_macAddressCache.contains(entry.ip().toString())) {
                                arpResults.append(qMakePair(entry.ip(), hwMac));
                                m_macAddressCache.insert(entry.ip().toString(), hwMac);
                                qDebug() << "添加本地接口: " << entry.ip().toString() << "/" << hwMac;
                            }
                            
                            // 为子网内的一些常见IP生成伪MAC地址
                            QHostAddress baseAddress(entry.ip().toIPv4Address() & entry.netmask().toIPv4Address());
                            for (int i = 1; i <= 10; i++) {  // 只生成少量IP进行测试
                                QHostAddress testIP(baseAddress.toIPv4Address() + i);
                                if (testIP != entry.ip()) {  // 跳过自己的IP
                                    QString pseudoMac = generatePseudoMACFromIP(testIP.toString());
                                    arpResults.append(qMakePair(testIP, pseudoMac));
                                    m_macAddressCache.insert(testIP.toString(), pseudoMac);
                                }
                            }
                        }
                    }
                }
            }
        }
    } catch (...) {
        qWarning() << "执行ARP扫描时发生异常";
    }
    
    qDebug() << "ARP扫描结果: " << arpResults.size() << "个条目";
    return arpResults;
}

// 禁用所有外部进程调用，使用固定的伪MAC地址
/**
 * @brief 执行外部进程并获取其输出 (已废弃)。
 * @param program 程序路径。
 * @param args 参数列表。
 * @param stdOutOutput 标准输出结果 (引用)。
 * @param stdErrOutput 标准错误结果 (引用)。
 * @param startTimeout 启动超时 (毫秒)。
 * @param finishTimeout 完成超时 (毫秒)。
 * @return 始终返回 false，因为外部进程调用已被禁用。
 * @note 为了提高稳定性和跨平台兼容性，此函数已被修改为不执行任何外部进程，
 *       并会设置 stdErrOutput 为 "禁用了外部进程"。
 */
bool NetworkScanner::executeProcess(const QString &program, const QStringList &args, QString &stdOutOutput, QString &stdErrOutput, int startTimeout, int finishTimeout) {
    // 为了完全稳定，不再使用外部进程
    Q_UNUSED(program)
    Q_UNUSED(args)
    Q_UNUSED(startTimeout)
    Q_UNUSED(finishTimeout)
    
    // 静默失败，返回空结果
    stdOutOutput = "";
    stdErrOutput = "禁用了外部进程";
    
    return false;
}

// 生成伪MAC地址，格式上明确标记为模拟数据
/**
 * @brief 根据IP地址生成一个格式化的伪MAC地址。
 * @param ip IP地址字符串 (例如 "192.168.1.10")。
 * @return 伪MAC地址字符串，格式为 "SM:XX:XX:XX:XX"，其中XX是IP地址各部分的十六进制表示。
 *         如果IP格式无效，则返回一个固定的默认伪MAC "SM:00:00:00:01"。
 * @details "SM" 前缀用于标识这是一个模拟的MAC地址。
 */
QString NetworkScanner::generatePseudoMACFromIP(const QString &ip)
{
    try {
        QStringList ipParts = ip.split(".");
        if (ipParts.size() == 4) {
            // 使用固定前缀SIM-表示这是模拟MAC
            int octet1 = ipParts[0].toInt() % 256;
            int octet2 = ipParts[1].toInt() % 256;
            int octet3 = ipParts[2].toInt() % 256;
            int octet4 = ipParts[3].toInt() % 256;
            
            QString pseudoMac = QString("SM:%1:%2:%3:%4")
                               .arg(octet1, 2, 16, QChar('0'))
                               .arg(octet2, 2, 16, QChar('0'))
                               .arg(octet3, 2, 16, QChar('0'))
                               .arg(octet4, 2, 16, QChar('0'));
            
            return pseudoMac.toUpper();
        }
    } catch (...) {
        qWarning() << "生成伪MAC时发生异常，返回默认MAC: " << ip;
    }
    
    // 如果发生任何问题，返回一个固定的MAC地址
    return "SM:00:00:00:01";
}

// 实现ScanStrategy构造函数
/**
 * @brief ScanStrategy 构造函数。
 * @param mode 扫描模式，默认为 STANDARD_SCAN。
 */
ScanStrategy::ScanStrategy(ScanMode mode) : m_mode(mode)
{
    // 初始化响应时间映射
}

/**
 * @brief 根据当前扫描模式获取推荐扫描的端口列表。
 * @return QList<int> 包含端口号的列表。
 * @details - QUICK_SCAN: 返回少量最常用端口 (如 80, 443, 22, 3389)。
 *          - STANDARD_SCAN: 返回一组常用服务端口。
 *          - DEEP_SCAN: 返回更广泛的端口列表，包括不常用端口和特定服务端口。
 */
QList<int> ScanStrategy::getPortsToScan() const
{
    QList<int> ports;
    
    switch (m_mode) {
        case QUICK_SCAN:
            // 快速扫描只检查几个最常用的端口
            ports << 80 << 443 << 22 << 3389;
            break;
            
        case STANDARD_SCAN:
            // 标准扫描包含常用服务端口
            ports << 21 << 22 << 23 << 25 << 53 << 80 << 110 << 135 << 139 << 143 << 443 << 445 << 993 << 995 << 1723 << 3306 << 3389 << 5900 << 8080;
            break;
            
        case DEEP_SCAN:
            // 深度扫描包含更多端口
            ports << 21 << 22 << 23 << 25 << 53 << 80 << 110 << 135 << 139 << 143 << 443 << 445 << 993 << 995 << 1723 << 3306 << 3389 << 5900 << 8080;
            // 添加更多不太常用的端口
            ports << 8443 << 8888 << 9000 << 9090 << 9443 << 10000 << 49152 << 49153 << 49154 << 49155;
            // 添加数据库和其他服务端口
            ports << 1433 << 1434 << 1521 << 1522 << 3306 << 5432 << 27017 << 27018 << 27019 << 6379;
            // 添加安全相关端口
            ports << 161 << 162 << 389 << 636 << 989 << 990 << 5060 << 5061;
            break;
    }
    
    return ports;
}

/**
 * @brief 根据IP地址和当前扫描模式获取推荐的扫描超时时间。
 * @param ip 目标IP地址字符串。
 * @return 超时时间（毫秒）。
 * @details 如果该IP有历史响应时间记录 (m_hostResponseTimes)，则基于历史时间计算超时 (乘以2，上限5000ms)。
 *          否则，根据扫描模式返回默认超时：QUICK_SCAN (200ms), STANDARD_SCAN (500ms), DEEP_SCAN (1000ms)。
 */
int ScanStrategy::getScanTimeout(const QString &ip) const
{
    // 如果有历史响应时间，根据历史响应时间设置合适的超时
    if (m_hostResponseTimes.contains(ip)) {
        int historyTime = m_hostResponseTimes[ip];
        // 添加一些余量
        return qMin(5000, historyTime * 2);
    }
    
    // 默认超时时间，根据扫描模式调整
    switch (m_mode) {
        case QUICK_SCAN:
            return 200;  // 快速模式下使用较短的超时
        case STANDARD_SCAN:
            return 500;  // 标准模式
        case DEEP_SCAN:
            return 1000; // 深度模式使用较长的超时
        default:
            return 500;
    }
}

/**
 * @brief 根据当前扫描模式获取推荐的最大并行任务数。
 * @return 并行任务数量。
 * @details 基于 QThread::idealThreadCount() (CPU核心数) 计算：
 *          - QUICK_SCAN: 返回核心数的2倍。
 *          - STANDARD_SCAN: 返回核心数。
 *          - DEEP_SCAN: 返回核心数的一半 (至少为1)。
 */
int ScanStrategy::getMaxParallelTasks() const
{
    // 获取CPU核心数
    int cpuCount = QThread::idealThreadCount();
    if (cpuCount <= 0) cpuCount = 2; // 默认至少2个
    
    switch (m_mode) {
        case QUICK_SCAN:
            return cpuCount * 2; // 快速模式下可以用更多线程
        case STANDARD_SCAN:
            return cpuCount;     // 标准模式使用核心数量的线程
        case DEEP_SCAN:
            return qMax(1, cpuCount / 2); // 深度模式减少并行度，避免过度占用资源
        default:
            return cpuCount;
    }
}

/**
 * @brief 更新指定IP地址的历史响应时间记录。
 * @param ip 主机IP地址字符串。
 * @param responseTime 新的响应时间（毫秒）。
 * @details 如果该IP已有历史记录，则使用加权平均 (旧时间权重0.8，新时间权重0.2) 平滑更新。
 *          如果响应时间小于等于0，则不更新。
 */
void ScanStrategy::updateHostResponseTime(const QString &ip, int responseTime)
{
    if (responseTime > 0) {
        // 如果已有历史数据，进行平滑更新
        if (m_hostResponseTimes.contains(ip)) {
            // 以8:2的比例平滑更新
            int oldTime = m_hostResponseTimes[ip];
            m_hostResponseTimes[ip] = (oldTime * 8 + responseTime * 2) / 10;
        } else {
            m_hostResponseTimes[ip] = responseTime;
        }
    }
}

// 实现ScanTask构造函数和run方法
/**
 * @brief ScanTask 构造函数。
 * @param parent 父对象指针，通常是 NetworkScanner 实例。
 * @param address 要扫描的 QHostAddress。
 * @param ports 要扫描的端口列表。
 * @param timeout 单个端口连接的超时时间（毫秒）。
 * @details 初始化扫描任务，并设置 QRunnable::setAutoDelete(true) 以便在任务完成后自动删除。
 */
ScanTask::ScanTask(QObject* parent, const QHostAddress &address, 
                 const QList<int> &ports, int timeout)
    : m_parent(parent), m_address(address), m_ports(ports), m_timeout(timeout)
{
    setAutoDelete(true);
}

/**
 * @brief 执行单个主机的扫描任务，在线程池中运行。
 * @details 此方法是 QRunnable::run() 的实现。
 *          它会创建一个 HostInfo 结构体，然后尝试通过连接指定端口 (列表中的前3个) 来判断主机是否可达。
 *          如果主机可达，会进一步尝试获取主机名和生成伪MAC地址。
 *          最后，通过 Qt::QueuedConnection 调用父对象 (NetworkScanner) 的 onScanTaskFinished() 槽函数来报告结果。
 */
void ScanTask::run()
{
    // 创建主机信息结构
    HostInfo hostInfo;
    hostInfo.ipAddress = m_address.toString();
    hostInfo.scanTime = QDateTime::currentDateTime();
    
    // 使用TCP尝试连接指定端口来判断主机是否可达，但限制尝试的端口数量
    bool isReachable = false;
    QElapsedTimer timer;
    timer.start();
    
    // 只尝试前3个端口，避免长时间阻塞
    QList<int> portsToTry = m_ports;
    if (portsToTry.size() > 3) {
        portsToTry = portsToTry.mid(0, 3);
    }
    
    for (int port : portsToTry) {
        if (!isReachable) {  // 一旦找到可达端口就不再尝试其他端口
            QTcpSocket socket;
            socket.connectToHost(m_address, port);
            
            // 减少超时时间，避免长时间阻塞
            int actualTimeout = qMin(m_timeout, 300);
            
            if (socket.waitForConnected(actualTimeout)) {
                isReachable = true;
                hostInfo.openPorts[port] = true;
                socket.disconnectFromHost();
            } else {
                hostInfo.openPorts[port] = false;
            }
        }
    }
    
    // 记录总的响应时间
    int responseTime = timer.elapsed();
    
    hostInfo.isReachable = isReachable;
    
    // 获取父对象
    NetworkScanner* scanner = qobject_cast<NetworkScanner*>(m_parent);
    if (scanner) {
        // 所有主机都记录，不仅限于可达主机
        hostInfo.hostName = isReachable ? 
                          scanner->lookupHostName(m_address) : 
                          m_address.toString();
        hostInfo.macAddress = scanner->generatePseudoMACFromIP(m_address.toString());
        hostInfo.macVendor = scanner->lookupMacVendor(hostInfo.macAddress);
        
        // 发送任务完成信号
        QMetaObject::invokeMethod(scanner, "onScanTaskFinished", 
                                Qt::QueuedConnection,
                                Q_ARG(HostInfo, hostInfo));
    }
}

// 重新实现NetworkScanner::onScanTaskFinished方法
/**
 * @brief 处理一个扫描任务完成的槽函数 (由 ScanTask 通过信号槽机制异步调用)。
 * @param hostInfo 包含扫描结果的 HostInfo 结构体。
 * @details 此方法在主线程中执行。它会将接收到的 hostInfo 添加到 m_scannedHostsList (受互斥锁保护)，
 *          发出 hostFound() 信号，并调用 updateScanProgress() 更新整体扫描进度。
 */
void NetworkScanner::onScanTaskFinished(const HostInfo &hostInfo)
{
    // 使用锁保护对共享数据的访问
    QMutexLocker locker(&m_mutex);
    
    // 添加所有主机，不仅限于可达主机
    m_scannedHostsList.append(hostInfo);
    
    // 发送找到的主机信号
    emit hostFound(hostInfo);
    
    // 更新进度
    m_scannedHosts++;
    updateScanProgress();
}

// 重新实现NetworkScanner::updateScanProgress方法
/**
 * @brief 更新整体扫描进度。
 * @details 此方法计算当前扫描进度百分比 ((m_scannedHosts * 100) / m_totalHosts)，
 *          并发出 scanProgress() 信号。
 *          如果已扫描主机数达到总主机数 (m_scannedHosts >= m_totalHosts) 且扫描仍在进行 (m_isScanning)，
 *          则将 m_isScanning 设置为 false 并发出 scanFinished() 信号。
 */
void NetworkScanner::updateScanProgress()
{
    if (m_totalHosts > 0) {
        int progress = (m_scannedHosts * 100) / m_totalHosts;
        emit scanProgress(progress);
        
        // 如果所有主机都已扫描完成，发送扫描完成信号
        if (m_scannedHosts >= m_totalHosts && m_isScanning) {
            m_isScanning = false;
            emit scanFinished();
        }
    }
}

// 添加用于异步主机名查询的槽
/**
 * @brief 当异步主机名查询 (QHostInfo::lookupHost()) 完成后调用的槽函数。
 * @param hostInfo QHostInfo 对象，包含查询结果 (IP地址、主机名、错误信息等)。
 * @details 如果查询成功且获取到主机名，则会更新 m_scannedHostsList 中对应IP地址条目的主机名，
 *          并重新发出 hostFound() 信号以通知UI更新。
 */
void NetworkScanner::onHostNameLookedUp(const QHostInfo &hostInfo)
{
    if (hostInfo.error() != QHostInfo::NoError) {
        return;
    }
    
    QString ip = hostInfo.addresses().isEmpty() ? "" : hostInfo.addresses().first().toString();
    if (ip.isEmpty()) {
        return;
    }
    
    QString hostName = hostInfo.hostName();
    if (hostName.isEmpty()) {
        return;
    }
    
    // 更新缓存和现有结果
    QMutexLocker locker(&m_mutex);
    
    // 更新扫描列表中的主机名
    for (int i = 0; i < m_scannedHostsList.size(); ++i) {
        if (m_scannedHostsList[i].ipAddress == ip) {
            m_scannedHostsList[i].hostName = hostName;
            // 发送更新信号
            emit hostFound(m_scannedHostsList[i]);
            break;
        }
    }
}

// 新增一个方法，使用更强力的方式终止所有ping进程
/**
 * @brief 强制终止所有正在运行的ping进程 (通常使用 kill -9 或 taskkill /F)。
 * @details 此方法会根据操作系统使用特定的系统命令来强制结束所有名为 "ping" 或 "ping.exe" 的进程。
 *          在macOS和Linux上，会多次尝试并验证清理效果。也会输出警告如果仍有进程未能终止。
 */
void NetworkScanner::forceKillAllPingProcesses()
{
#ifdef Q_OS_MACOS
    // 使用强制的方式彻底终止所有ping进程
    system("killall -9 ping 2>/dev/null || true");
    
    // 确保清理所有进程ID
    QProcess pgrep;
    pgrep.start("pgrep", QStringList() << "ping");
    pgrep.waitForFinished(300);
    QString output = QString::fromLocal8Bit(pgrep.readAllStandardOutput()).trimmed();
    if (!output.isEmpty()) {
        QStringList pids = output.split('\n', Qt::SkipEmptyParts);
        for (const QString &pid : pids) {
            bool ok;
            qint64 pidNum = pid.toLongLong(&ok);
            if (ok && pidNum > 0) {
                QString cmd = QString("kill -9 %1 2>/dev/null || true").arg(pidNum);
                system(cmd.toStdString().c_str());
            }
        }
    }
    
    // 再等待一小段时间确保系统有时间处理
    QThread::msleep(100);
    
    // 最终验证
    QProcess finalCheck;
    finalCheck.start("pgrep", QStringList() << "ping");
    finalCheck.waitForFinished(300);
    QString finalOutput = QString::fromLocal8Bit(finalCheck.readAllStandardOutput()).trimmed();
    if (!finalOutput.isEmpty()) {
        qDebug() << "警告: 仍有ping进程未能终止, 数量: " << finalOutput.split('\n', Qt::SkipEmptyParts).size();
    }
#elif defined(Q_OS_WIN)
    // Windows上使用taskkill强制终止
    system("taskkill /F /IM ping.exe /T >nul 2>&1");
    
    // 等待处理
    QThread::msleep(100);
    
    // 最终验证
    QProcess tasklist;
    tasklist.start("tasklist", QStringList() << "/FI" << "IMAGENAME eq ping.exe" << "/NH" << "/FO" << "CSV");
    tasklist.waitForFinished(300);
    QString output = QString::fromLocal8Bit(tasklist.readAllStandardOutput());
    if (output.contains("ping.exe")) {
        qDebug() << "警告: Windows上仍有ping进程未能终止";
    }
#else
    // Linux上使用kill -9
    system("pkill -9 ping 2>/dev/null || true");
    
    // 等待处理
    QThread::msleep(100);
    
    // 最终验证
    QProcess pgrep;
    pgrep.start("pgrep", QStringList() << "ping");
    pgrep.waitForFinished(300);
    QString output = QString::fromLocal8Bit(pgrep.readAllStandardOutput()).trimmed();
    if (!output.isEmpty()) {
        qDebug() << "警告: Linux上仍有ping进程未能终止, 数量: " << output.split('\n', Qt::SkipEmptyParts).size();
    }
#endif
} 
