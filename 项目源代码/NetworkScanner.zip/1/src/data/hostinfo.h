/**
 * @file hostinfo.h
 * @brief 定义网络扫描中主机和端口信息的结构体。
 *  
 * 
 * @copyright Copyright (c) 2024
 */

#ifndef HOSTINFO_H
#define HOSTINFO_H

#include <QString>
#include <QList>

/**
 * @struct PortInfo
 * @brief 存储单个端口的信息。
 */
struct PortInfo {
    int portNumber;         ///< @brief 端口号。
    QString serviceName;    ///< @brief 端口上运行的服务名称 (例如 http, ftp)。
    QString protocol;       ///< @brief 端口使用的协议 (例如 TCP, UDP)。
    QString state;          ///< @brief 端口状态 (例如 open, closed, filtered)。
};

/**
 * @struct HostInfo
 * @brief 存储扫描到的单个主机的详细信息。
 */
struct HostInfo {
    QString ipAddress;          ///< @brief 主机的IP地址。
    QString macAddress;         ///< @brief 主机的MAC地址 (如果可获取)。
    QString hostname;           ///< @brief 主机的主机名 (如果可解析)。
    QString os;                 ///< @brief 推测的主机操作系统。
    QList<PortInfo> openPorts;  ///< @brief 主机上开放的端口列表。
    int ttl;                    ///< @brief 从扫描器到主机的初始TTL值。
    qint64 responseTime;        ///< @brief 主机的响应时间 (例如 ping 延迟，单位毫秒)。
    // QString vendor;          ///< @brief 设备制造商 (通过MAC地址推断)。
    // DeviceType inferredType; ///< @brief 基于分析推断的设备类型。
};

#endif // HOSTINFO_H 