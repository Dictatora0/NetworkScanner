/**
 * @file scanhistory.h
 * @brief 定义扫描历史记录的管理类和相关数据结构。
 *   
 * 
 * @copyright Copyright (c) 2024
 */

#ifndef SCANHISTORY_H
#define SCANHISTORY_H

#include <QObject> // For potential signals/slots if history operations are async or notify UI
#include <QList>
#include <QString>
#include <QDateTime>
#include "./hostinfo.h" // HostInfo is in the same 'data' directory

/**
 * @struct ScanSession
 * @brief 存储一次完整的扫描会话信息。
 */
struct ScanSession {
    QString sessionId;          ///< @brief 本次扫描会话的唯一ID (例如 UUID 或时间戳字符串)。
    QDateTime startTime;        ///< @brief 扫描开始时间。
    QDateTime endTime;          ///< @brief 扫描结束时间。
    QString scanTarget;         ///< @brief 本次扫描的目标 (例如 "192.168.1.0/24")。
    int deviceCount;            ///< @brief 本次扫描发现的设备数量。
    QList<HostInfo> foundHosts; ///< @brief 本次扫描发现的所有主机的详细信息。
    QString notes;              ///< @brief 用户为本次扫描添加的备注 (可选)。
    // 可以添加其他元数据，如扫描配置参数等
};

/**
 * @class ScanHistoryManager
 * @brief 管理扫描历史记录的类。
 *
 * 负责加载、保存、查询和删除扫描会话。历史记录可以存储在
 * 文件（如JSON, XML, SQLite）或数据库中。
 */
class ScanHistoryManager : public QObject
{
    Q_OBJECT

public:
    /**
     * @brief ScanHistoryManager 构造函数。
     * @param storagePath 历史记录的存储路径或数据库连接字符串。默认为空，可能使用默认位置。
     * @param parent 父QObject，默认为nullptr。
     */
    explicit ScanHistoryManager(const QString &storagePath = QString(), QObject *parent = nullptr);

    /**
     * @brief ScanHistoryManager 析构函数。
     *
     * 确保在对象销毁前所有挂起的历史记录更改都已保存。
     */
    ~ScanHistoryManager();

    /**
     * @brief 添加一次新的扫描会话到历史记录中。
     * @param session 要添加的扫描会话数据。
     * @return 如果成功添加则返回true，否则返回false (例如，存储失败)。
     */
    bool addScanSession(const ScanSession &session);

    /**
     * @brief 获取所有已保存的扫描会话。
     * @return ScanSession 对象的列表，按时间倒序排列 (最新的在前)。
     */
    QList<ScanSession> getAllScanSessions() const;

    /**
     * @brief 根据会话ID获取特定的扫描会话。
     * @param sessionId 要检索的扫描会话的ID。
     * @param sessionFound [out] 如果找到会话，此引用将被设置为true。
     * @return 如果找到，则返回 ScanSession 对象；否则返回一个空的或无效的 ScanSession。
     */
    ScanSession getScanSession(const QString &sessionId, bool *sessionFound = nullptr) const;

    /**
     * @brief 删除指定ID的扫描会话。
     * @param sessionId 要删除的扫描会话的ID。
     * @return 如果成功删除则返回true，否则返回false。
     */
    bool deleteScanSession(const QString &sessionId);

    /**
     * @brief 清除所有的扫描历史记录。
     * @return 如果成功清除所有记录则返回true，否则返回false。
     */
    bool clearAllHistory();

    /**
     * @brief 加载历史记录。
     *
     * 从指定的存储位置（文件或数据库）加载历史记录到内存中。
     * 通常在构造时或显式调用时执行。
     * @return 如果成功加载则返回true，否则返回false。
     */
    bool loadHistory();

    /**
     * @brief 保存当前内存中的历史记录到持久化存储。
     *
     * 可以在每次更改后自动调用，或在程序退出前显式调用。
     * @return 如果成功保存则返回true，否则返回false。
     */
    bool saveHistory() const;

signals:
    /**
     * @brief 当历史记录发生更改时（例如添加或删除会话）发射此信号。
     */
    void historyChanged();

private:
    QString m_storagePath;              ///< @brief 历史记录文件的路径或数据库连接信息。
    QList<ScanSession> m_sessions;    ///< @brief 内存中缓存的扫描会话列表。

   
};

#endif // SCANHISTORY_H 