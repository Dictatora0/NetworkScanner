/**
 * @file deviceanalyzer.h
 * @brief 定义设备分析类，用于统计和分析扫描到的设备信息。
 * 
 * @copyright Copyright (c) 2024
 */

#ifndef DEVICEANALYZER_H
#define DEVICEANALYZER_H

#include <QObject> // 可能需要QObject以支持异步分析或信号
#include <QList>
#include <QMap>
#include <QString>
#include "../data/hostinfo.h"
#include "../common/types.h" // For DeviceType enum

/**
 * @struct DeviceStats
 * @brief 存储设备统计信息。
 */
struct DeviceStats {
    int totalDevices;                       ///< @brief 设备总数。
    QMap<DeviceType, int> countByType;      ///< @brief 按设备类型统计的数量。
    QMap<QString, int> countByOS;           ///< @brief 按操作系统统计的数量。
    QMap<QString, int> countByVendor;       ///< @brief 按设备制造商统计的数量 (基于MAC地址)。
    QList<QString> commonOpenPorts;         ///< @brief 常见的开放端口列表。
    // 可以添加更多统计维度，例如平均响应时间、存活主机百分比等
};

/**
 * @class DeviceAnalyzer
 * @brief 负责对扫描到的主机列表进行深入分析和统计。
 *
 * 此类接收一批 HostInfo 对象，并从中提取统计数据，
 * 例如设备类型分布、操作系统分布、常见开放端口等。
 */
class DeviceAnalyzer : public QObject
{
    Q_OBJECT

public:
    /**
     * @brief DeviceAnalyzer 构造函数。
     * @param parent 父QObject，默认为nullptr。
     */
    explicit DeviceAnalyzer(QObject *parent = nullptr);

    /**
     * @brief 设置用于分析的主机数据。
     * @param hosts 从网络扫描获取的主机信息列表。
     */
    void setHostData(const QList<HostInfo> &hosts);

    /**
     * @brief 执行分析操作。
     *
     * 分析结果可以通过信号或直接返回一个包含统计数据的结构体。
     * 对于耗时较长的分析，可以考虑异步执行。
     * @return DeviceStats 结构体，包含分析结果。
     */
    DeviceStats analyze(); 

    /**
     * @brief 根据主机信息推断设备类型。
     * @param host 单个主机的信息。
     * @return 推断出的 DeviceType。
     * @note 这个方法也可以是 TopologyAnalyzer 的一部分，或者是一个共享的工具函数。
     *       如果在这里实现，它可能基于开放端口、OS信息等进行推断。
     */
    DeviceType inferDeviceType(const HostInfo &host) const;

    /**
     * @brief 从MAC地址推断设备制造商。
     * @param macAddress 主机的MAC地址。
     * @return 设备制造商的名称，如果无法确定则返回空字符串或"Unknown"。
     * @note 此功能通常需要一个MAC地址到制造商的数据库（OUI数据库）。
     */
    QString inferVendorFromMac(const QString &macAddress) const;

    // 可以添加更多特定的分析方法，例如：
    // QMap<QString, int> getOperatingSystemDistribution() const;
    // QMap<DeviceType, int> getDeviceTypeDistribution() const;
    // QList<PortInfo> getMostCommonOpenPorts(int topN = 10) const;

signals:
    /**
     * @brief 当分析完成时发射此信号（如果分析是异步的）。
     * @param stats 分析得到的统计数据。
     */
    void analysisComplete(const DeviceStats &stats);

private:
    QList<HostInfo> m_hosts; ///< @brief 当前用于分析的主机数据。
    DeviceStats m_currentStats; ///< @brief 当前的统计结果。

    // 内部可能需要OUI数据库的引用或加载逻辑
    // QMap<QString, QString> m_ouiDatabase; 
};

#endif // DEVICEANALYZER_H 