/**
 * @file networkscanner.h
 * @brief 定义网络扫描器核心类，负责执行网络发现和主机信息收集。
 *   
 * 
 * @copyright Copyright (c) 2024
 */

#ifndef NETWORKSCANNER_H
#define NETWORKSCANNER_H

#include <QObject> // NetworkScanner 可能需要 QObject 以支持信号和槽
#include <QStringList>
#include <QNetworkInterface> // 用于获取本地网络接口信息
#include "../data/hostinfo.h" // 包含 HostInfo 结构体

/**
 * @class NetworkScanner
 * @brief 核心网络扫描类。
 *
 *此类负责发现本地网络中的活动主机，并收集每个主机的详细信息，
 * 如IP地址、MAC地址、开放端口、操作系统等。
 * 它可能会使用多种扫描技术（如ARP扫描、ICMP ping、端口扫描等）。
 * 
 * @note 此类可能需要以提升的权限运行以执行某些扫描操作（如原始套接字访问）。
 */
class NetworkScanner : public QObject
{
    Q_OBJECT

public:
    /**
     * @brief NetworkScanner 构造函数。
     * @param parent 父QObject，默认为nullptr。
     */
    explicit NetworkScanner(QObject *parent = nullptr);

    /**
     * @brief NetworkScanner 析构函数。
     */
    ~NetworkScanner();

    /**
     * @brief 设置要扫描的目标IP范围或子网。
     * @param targets IP地址列表、IP范围 (例如 "192.168.1.1-192.168.1.254") 
     *                或子网掩码 (例如 "192.168.1.0/24")。
     */
    void setScanTargets(const QStringList &targets);

    /**
     * @brief 设置扫描参数/配置。
     * 
     * 例如，可以设置端口扫描范围、超时时间、使用的扫描方法等。
     * @param config 一个包含配置选项的结构体或QVariantMap。
     */
    // void setScanConfiguration(const ScanConfig &config); // ScanConfig 需要定义

    /**
     * @brief 开始网络扫描。
     *
     * 这是一个异步操作。扫描进度和结果通过信号报告。
     * @see scanProgress, hostFound, scanFinished
     */
    void startScan();

    /**
     * @brief 停止当前正在进行的扫描。
     */
    void stopScan();

    /**
     * @brief 获取当前扫描状态。
     * @return 如果正在扫描则返回true，否则返回false。
     */
    bool isScanning() const;

    /**
     * @brief 获取本地网络接口列表。
     * @return QNetworkInterface 对象列表。
     */
    QList<QNetworkInterface> getLocalInterfaces();

    // 更多具体的扫描方法可以根据需要添加，例如：
    // void performArpScan(const QString &subnet); // 执行ARP扫描
    // void performPingSweep(const QString &subnet); // 执行Ping扫描
    // void scanPorts(const QString &ipAddress, const QList<int> &ports); // 扫描指定主机的端口

signals:
    /**
     * @brief 当发现一个活动主机时发射此信号。
     * @param hostInfo 发现的主机的详细信息。
     */
    void hostFound(const HostInfo &hostInfo);

    /**
     * @brief 报告扫描进度。
     * @param percentage 完成百分比 (0-100)。
     * @param message 当前扫描状态的描述性消息。
     */
    void scanProgress(int percentage, const QString &message);

    /**
     * @brief 当整个扫描过程完成时发射此信号。
     * @param results 所有发现的主机列表。
     */
    void scanFinished(const QList<HostInfo> &results);

    /**
     * @brief 当扫描过程中发生错误时发射此信号。
     * @param errorMessage 错误信息描述。
     */
    void scanError(const QString &errorMessage);

private slots:
    // 私有槽函数，用于处理内部异步操作的结果等

private:
    QStringList m_targets;       ///< @brief 当前要扫描的目标列表。
    bool m_isScanning;           ///< @brief 标记当前是否正在进行扫描。
    QList<HostInfo> m_foundHosts; ///< @brief 本次扫描已发现的主机列表。

    // 内部实现细节，例如线程、进程管理、原始套接字等
};

#endif // NETWORKSCANNER_H 