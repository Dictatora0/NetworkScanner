/**
 * @file topologyanalyzer.h
 * @brief 定义网络拓扑分析器类，用于分析和推断网络结构。
 *  
 * 
 * @copyright Copyright (c) 2024
 */

#ifndef TOPOLOGYANALYZER_H
#define TOPOLOGYANALYZER_H

#include <QMap>
#include <QStringList>
#include <QProcess> // 包含 QProcess
#include "../common/types.h" // 包含枚举类型
#include "../data/hostinfo.h" // 更新为正确的 HostInfo路径
                                // 如果在 networkscanner.h，则改为 #include "networkscanner.h"

/**
 * @class TopologyAnalyzer
 * @brief 负责分析原始主机数据，推断设备连接、网络层次和子网结构。
 *
 * 此类提供了一系列方法来处理 `HostInfo` 列表，并从中提取
 * 网络拓扑相关的结构化信息。
 */
class TopologyAnalyzer {
public:
    /**
     * @brief TopologyAnalyzer 构造函数。
     */
    TopologyAnalyzer();

    /**
     * @brief 推断设备之间的连接关系。
     * @param hosts 扫描到的主机信息列表。
     * @return 返回一个映射，键是设备IP，值是与其有直接或间接连接的设备IP列表。
     *         连接关系可能基于traceroute结果、TTL差异等。
     */
    QMap<QString, QStringList> inferDeviceConnections(const QList<HostInfo> &hosts);

    /**
     * @brief 分析网络的层次结构，通常基于TTL值。
     * @param hosts 扫描到的主机信息列表。
     * @return 返回一个映射，键是网络层级（例如，基于TTL的跳数），值是该层级下的设备IP列表。
     */
    QMap<int, QStringList> analyzeTTLLayers(const QList<HostInfo> &hosts);

    /**
     * @brief 分析网络中的子网结构。
     * @param hosts 扫描到的主机信息列表。
     * @return 返回一个映射，键是子网ID（例如 "192.168.1.0/24"），值是该子网下的设备IP列表。
     */
    QMap<QString, QStringList> analyzeSubnets(const QList<HostInfo> &hosts);

    /**
     * @brief 基于设备响应时间对设备进行聚类。
     * @param hosts 扫描到的主机信息列表。
     * @return 返回一个列表，其中每个子列表代表一个设备集群（集群内设备响应时间相近）。
     */
    QList<QStringList> clusterDevicesByResponseTime(const QList<HostInfo> &hosts);

    /**
     * @brief 获取特定IP地址的TTL（Time To Live）值。
     *
     * 此方法可能通过ping命令或预存的HostInfo数据获取TTL。
     * @param ipAddress 目标设备的IP地址。
     * @return 成功则返回TTL值，失败或无法获取则返回一个特殊值（如-1）。
     */
    int getTTLValue(const QString &ipAddress);

    /**
     * @brief 执行traceroute命令以获取到目标IP的路径信息。
     *
     * 注意：执行外部命令可能需要适当的权限，并且耗时较长。
     * @param targetIP 目标设备的IP地址。
     * @return 返回一个字符串列表，包含traceroute路径上的每一跳IP地址。
     *         如果traceroute失败或目标不可达，可能返回空列表或包含错误信息。
     */
    QStringList performTraceRoute(const QString &targetIP);

    /**
     * @brief 根据IP地址和前缀长度计算子网掩码和网络地址。
     * @param ip IP地址字符串 (例如 "192.168.1.10")。
     * @param prefixLength 子网前缀长度 (例如 24 for /24)。
     * @return 返回子网的网络地址字符串 (例如 "192.168.1.0")。
     */
    QString calculateSubnet(const QString &ip, int prefixLength = 24);

    /**
     * @brief 判断两个IP地址是否位于同一个子网中。
     * @param ip1 第一个IP地址。
     * @param ip2 第二个IP地址。
     * @param prefixLength 子网前缀长度，默认为24。
     * @return 如果两个IP在同一个指定前缀长度的子网中，则返回true；否则返回false。
     */
    bool inSameSubnet(const QString &ip1, const QString &ip2, int prefixLength = 24);

private:
    // 私有成员和辅助方法可以根据实现需要添加
};

#endif // TOPOLOGYANALYZER_H 