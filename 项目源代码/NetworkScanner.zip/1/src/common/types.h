/**
 * @file types.h
 * @brief 定义项目中通用的枚举类型。
 */

#ifndef COMMON_TYPES_H
#define COMMON_TYPES_H

/**
 * @enum DeviceType
 * @brief 定义网络设备的类型。
 */
enum DeviceType {
    DEVICE_UNKNOWN,    ///< 未知设备
    DEVICE_ROUTER,     ///< 路由器
    DEVICE_SERVER,     ///< 服务器
    DEVICE_PC,         ///< 个人电脑
    DEVICE_MOBILE,     ///< 移动设备
    DEVICE_PRINTER,    ///< 打印机
    DEVICE_IOT         ///< 物联网设备
};

/**
 * @enum ConnectionType
 * @brief 定义设备之间的连接类型。
 */
enum ConnectionType {
    CONNECTION_UNKNOWN,  ///< 未知连接
    CONNECTION_DIRECT,   ///< 直接连接
    CONNECTION_WIRELESS, ///< 无线连接
    CONNECTION_VPN,      ///< VPN连接
    CONNECTION_ROUTED    ///< 通过路由器连接
};

// 假设 HostInfo 结构体也属于通用类型，如果它在 networkscanner.h 中定义，则不需要在此处重复。
// 如果它是一个独立的通用结构体，可以像下面这样定义：
/*
#include <QString>
#include <QList>

struct PortInfo {
    int portNumber;
    QString serviceName;
    QString protocol; // TCP or UDP
};

struct HostInfo {
    QString ipAddress;
    QString macAddress;
    QString hostname;
    QString os;
    QList<PortInfo> openPorts;
    int ttl;
    qint64 responseTime; // in milliseconds
    // 其他可能的信息
};
*/

#endif // COMMON_TYPES_H 