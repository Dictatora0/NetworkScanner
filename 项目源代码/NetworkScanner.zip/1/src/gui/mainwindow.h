/**
 * @file mainwindow.h
 * @brief 定义应用程序的主窗口类。
 *   
 * 
 * @copyright Copyright (c) 2024
 */

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QList>
#include "../data/hostinfo.h" // For HostInfo struct

// 前向声明 ui 类 (如果使用 .ui 文件)
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

// 前向声明自定义组件
class NetworkScanner;       // 在 core 模块
class NetworkTopology;      // 在 gui 模块
class DeviceAnalyzerView;   // 假设的设备分析视图类 (可能在 gui 或新模块)
class ScanHistoryView;      // 假设的扫描历史视图类 (可能在 gui 或新模块)

/**
 * @class MainWindow
 * @brief 应用程序的主窗口，集成各个功能模块。
 *
 * MainWindow 负责组织用户界面，包括启动扫描、显示拓扑图、
 * 查看设备分析结果和管理扫描历史等。
 */
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    /**
     * @brief MainWindow 构造函数。
     * @param parent 父QWidget，默认为nullptr。
     */
    MainWindow(QWidget *parent = nullptr);

    /**
     * @brief MainWindow 析构函数。
     */
    ~MainWindow();

protected:
    /**
     * @brief 关闭事件处理程序。
     * @param event 关闭事件。
     */
    void closeEvent(QCloseEvent *event) override;

private slots:
    // UI 动作槽函数
    void on_actionStartScan_triggered();
    void on_actionStopScan_triggered();
    void on_actionConfigureScan_triggered();
    void on_actionViewTopology_triggered();
    void on_actionViewAnalysis_triggered();
    void on_actionViewHistory_triggered();
    void on_actionExit_triggered();
    void on_actionAbout_triggered();

    // NetworkScanner信号的槽函数
    void handleHostFound(const HostInfo &hostInfo);
    void handleScanProgress(int percentage, const QString &message);
    void handleScanFinished(const QList<HostInfo> &results);
    void handleScanError(const QString &errorMessage);

    // NetworkTopology信号的槽函数
    void handleDeviceSelectedFromTopology(const HostInfo &hostInfo);

private:
    /**
     * @brief 创建菜单栏。
     */
    void createMenus();

    /**
     * @brief 创建工具栏。
     */
    void createToolbars();

    /**
     * @brief 创建状态栏。
     */
    void createStatusbar();

    /**
     * @brief 创建并设置中央区域的停靠窗口或堆叠窗口。
     */
    void setupDockWidgets(); // 或者 setupCentralWidget()

    /**
     * @brief 读取应用程序设置。
     */
    void readSettings();

    /**
     * @brief 保存应用程序设置。
     */
    void writeSettings();

    Ui::MainWindow *ui; ///< @brief Qt Designer 生成的UI类实例 (如果使用.ui文件)。

    // 功能模块实例
    NetworkScanner *m_networkScanner;          ///< @brief 网络扫描器实例。
    NetworkTopology *m_networkTopologyWidget;  ///< @brief 网络拓扑图显示组件。
    // DeviceAnalyzerView *m_deviceAnalyzerView; ///< @brief 设备分析视图组件。
    // ScanHistoryView *m_scanHistoryView;       ///< @brief 扫描历史视图组件。

    // 其他成员变量
    QList<HostInfo> m_currentScanResults;     ///< @brief 当前扫描操作的结果缓存。
    QString m_currentScanTarget;              ///< @brief 当前扫描目标。
};

#endif // MAINWINDOW_H 