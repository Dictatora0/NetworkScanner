#include <QGraphicsItem>
#include <QMap>
// #include <QPair> // QPair 通常不需要单独包含，它是 QMap 的一部分或通过其他 Qt 模块间接包含
// #include <QProcess> // 已移至 TopologyAnalyzer
#include "../data/hostinfo.h"     // 直接包含 HostInfo
#include "../common/types.h"      // 包含 DeviceType, ConnectionType
#include "../core/topologyanalyzer.h" // 包含 TopologyAnalyzer


/**
 * @class DeviceNode
// ... existing code ... 