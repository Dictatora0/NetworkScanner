#include "scanhistory.h"
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <QFile>
#include <QDebug>

/**
 * @brief ScanHistory 构造函数。
 * @param parent 父对象指针。
 */
ScanHistory::ScanHistory(QObject *parent)
    : QObject(parent)
{
}

/**
 * @brief 添加一次新的扫描会话到历史记录。
 * @param hosts 本次扫描发现的主机列表。
 * @param description (可选) 会话的描述，默认为当前日期时间。
 * @details 创建一个新的 ScanSession 对象并添加到 m_sessions 列表中。
 *          如果描述为空，则使用当前日期时间作为描述。
 *          会触发 historyChanged() 信号。
 */
void ScanHistory::addSession(const QList<HostInfo> &hosts, const QString &description)
{
    QString sessionDesc = description;
    if (sessionDesc.isEmpty()) {
        sessionDesc = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss 扫描");
    }
    
    m_sessions.append(ScanSession(sessionDesc, hosts, hosts.size()));
    emit historyChanged();
}

/**
 * @brief 获取所有存储的扫描会话。
 * @return QList<ScanSession> 包含所有扫描会话的列表。
 */
QList<ScanSession> ScanHistory::getSessions() const
{
    return m_sessions;
}

/**
 * @brief 根据索引获取指定的扫描会话。
 * @param index 会话在列表中的索引。
 * @return ScanSession 指定的扫描会话。如果索引无效，则返回一个空的默认会话。
 */
ScanSession ScanHistory::getSession(int index) const
{
    if (index >= 0 && index < m_sessions.size()) {
        return m_sessions.at(index);
    }
    return ScanSession(); // 返回一个空的会话如果索引无效
}

/**
 * @brief 获取存储的扫描会话总数。
 * @return int 会话数量。
 */
int ScanHistory::sessionCount() const
{
    return m_sessions.size();
}

/**
 * @brief 根据索引移除一个扫描会话。
 * @param index 要移除的会话的索引。
 * @return 如果成功移除则返回 true，否则 (例如索引无效) 返回 false。
 * @details 会触发 historyChanged() 信号。
 */
bool ScanHistory::removeSession(int index)
{
    if (index >= 0 && index < m_sessions.size()) {
        m_sessions.removeAt(index);
        emit historyChanged();
        return true;
    }
    return false;
}

/**
 * @brief 清除所有扫描历史记录。
 * @details 会触发 historyChanged() 信号。
 */
void ScanHistory::clearHistory()
{
    m_sessions.clear();
    emit historyChanged();
}

/**
 * @brief 将扫描历史保存到文件 (JSON格式)。
 * @param filename 要保存的文件名。
 * @return 如果保存成功则返回 true，否则返回 false。
 */
bool ScanHistory::saveToFile(const QString &filename) const
{
    QJsonArray sessionsArray;
    for (const ScanSession &session : m_sessions) {
        QJsonObject sessionObject;
        sessionObject["dateTime"] = session.dateTime.toString(Qt::ISODate);
        sessionObject["description"] = session.description;
        sessionObject["totalHostsScanned"] = session.totalHostsScanned;
        
        QJsonArray hostsArray;
        for (const HostInfo &host : session.hosts) {
            QJsonObject hostObject;
            hostObject["ipAddress"] = host.ipAddress;
            hostObject["hostName"] = host.hostName;
            hostObject["macAddress"] = host.macAddress;
            hostObject["macVendor"] = host.macVendor;
            hostObject["isReachable"] = host.isReachable;
            hostObject["scanTime"] = host.scanTime.toString(Qt::ISODate);
            
            QJsonObject openPortsObject;
            QMapIterator<int, bool> i(host.openPorts);
            while (i.hasNext()) {
                i.next();
                openPortsObject[QString::number(i.key())] = i.value();
            }
            hostObject["openPorts"] = openPortsObject;
            hostsArray.append(hostObject);
        }
        sessionObject["hosts"] = hostsArray;
        sessionsArray.append(sessionObject);
    }
    
    QJsonDocument doc(sessionsArray);
    QFile file(filename);
    if (file.open(QIODevice::WriteOnly)) {
        file.write(doc.toJson());
        file.close();
        return true;
    }
    qWarning() << "无法保存扫描历史到文件:" << filename << file.errorString();
    return false;
}

/**
 * @brief 从文件加载扫描历史 (JSON格式)。
 * @param filename 要加载的文件名。
 * @return 如果加载成功则返回 true，否则返回 false。
 * @details 加载成功后会触发 historyChanged() 信号。
 */
bool ScanHistory::loadFromFile(const QString &filename)
{
    QFile file(filename);
    if (!file.open(QIODevice::ReadOnly)) {
        qWarning() << "无法打开扫描历史文件:" << filename << file.errorString();
        return false;
    }
    
    QByteArray data = file.readAll();
    file.close();
    
    QJsonDocument doc = QJsonDocument::fromJson(data);
    if (!doc.isArray()) {
        qWarning() << "扫描历史文件格式无效 (不是JSON数组):" << filename;
        return false;
    }
    
    m_sessions.clear();
    QJsonArray sessionsArray = doc.array();
    
    for (const QJsonValue &sessionValue : sessionsArray) {
        QJsonObject sessionObject = sessionValue.toObject();
        ScanSession session;
        session.dateTime = QDateTime::fromString(sessionObject["dateTime"].toString(), Qt::ISODate);
        session.description = sessionObject["description"].toString();
        session.totalHostsScanned = sessionObject["totalHostsScanned"].toInt();
        
        QJsonArray hostsArray = sessionObject["hosts"].toArray();
        for (const QJsonValue &hostValue : hostsArray) {
            QJsonObject hostObject = hostValue.toObject();
            HostInfo host;
            host.ipAddress = hostObject["ipAddress"].toString();
            host.hostName = hostObject["hostName"].toString();
            host.macAddress = hostObject["macAddress"].toString();
            host.macVendor = hostObject["macVendor"].toString();
            host.isReachable = hostObject["isReachable"].toBool();
            host.scanTime = QDateTime::fromString(hostObject["scanTime"].toString(), Qt::ISODate);
            
            QJsonObject openPortsObject = hostObject["openPorts"].toObject();
            for (auto it = openPortsObject.begin(); it != openPortsObject.end(); ++it) {
                host.openPorts[it.key().toInt()] = it.value().toBool();
            }
            session.hosts.append(host);
        }
        m_sessions.append(session);
    }
    
    emit historyChanged();
    return true;
}

/**
 * @brief 比较两次扫描会话的结果，找出新增和消失的主机。
 * @param index1 第一个会话的索引 (通常是较早的会话)。
 * @param index2 第二个会话的索引 (通常是较新的会话)。
 * @return QPair<QList<HostInfo>, QList<HostInfo>>
 *         - first: 在会话2中出现但未在会话1中出现的主机 (新增主机)。
 *         - second: 在会话1中出现但未在会话2中出现的主机 (消失主机)。
 * @throws std::out_of_range 如果索引无效。
 */
QPair<QList<HostInfo>, QList<HostInfo>> ScanHistory::compareScans(int index1, int index2) const
{
    if (index1 < 0 || index1 >= m_sessions.size() || 
        index2 < 0 || index2 >= m_sessions.size() || index1 == index2) {
        throw std::out_of_range("无效的扫描会话索引");
    }
    
    const ScanSession &session1 = m_sessions.at(index1);
    const ScanSession &session2 = m_sessions.at(index2);
    
    QList<HostInfo> newHosts;     // 在session2中出现，但在session1中未出现
    QList<HostInfo> missingHosts; // 在session1中出现，但在session2中未出现
    
    // 将session1中的主机IP存入QSet以便快速查找
    QSet<QString> session1IPs;
    for (const HostInfo &host : session1.hosts) {
        session1IPs.insert(host.ipAddress);
    }
    
    // 遍历session2，查找新增主机
    for (const HostInfo &host2 : session2.hosts) {
        if (!session1IPs.contains(host2.ipAddress)) {
            newHosts.append(host2);
        }
    }
    
    // 将session2中的主机IP存入QSet以便快速查找
    QSet<QString> session2IPs;
    for (const HostInfo &host : session2.hosts) {
        session2IPs.insert(host.ipAddress);
    }
    
    // 遍历session1，查找消失主机
    for (const HostInfo &host1 : session1.hosts) {
        if (!session2IPs.contains(host1.ipAddress)) {
            missingHosts.append(host1);
        }
    }
    
    return qMakePair(newHosts, missingHosts);
}

// ScanSession 辅助方法的实现
/**
 * @brief 计算并返回会话中可达主机的数量。
 * @return int 可达主机的数量。
 */
int ScanSession::reachableHosts() const
{
    int count = 0;
    for (const HostInfo &host : hosts) {
        if (host.isReachable) {
            count++;
        }
    }
    return count;
}

/**
 * @brief 计算并返回会话中各开放端口的分布情况。
 * @return QMap<int, int> 键为端口号，值为使用该端口的主机数量。
 */
QMap<int, int> ScanSession::portDistribution() const
{
    QMap<int, int> distribution;
    for (const HostInfo &host : hosts) {
        if (host.isReachable) {
            QMapIterator<int, bool> i(host.openPorts);
            while (i.hasNext()) {
                i.next();
                if (i.value()) { // 如果端口开放
                    distribution[i.key()]++;
                }
            }
        }
    }
    return distribution;
} 