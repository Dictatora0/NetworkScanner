#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTableWidget>
#include <QPushButton>
#include <QProgressBar>
#include <QLabel>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QStatusBar>
#include <QHeaderView>
#include <QMessageBox>
#include <QLineEdit>
#include <QComboBox>
#include <QSpinBox>
#include <QCheckBox>
#include <QGroupBox>
#include <QFileDialog>
#include <QAction>
#include <QMenu>
#include <QMenuBar>
#include <QTabWidget>
#include <QTextEdit>
#include <QSettings>
#include <QSplitter>
#include <QStyledItemDelegate>
#include <QApplication>
#include <QtCharts/QChartView>
#include <QtCharts/QChart>
#include <QGraphicsView>
#include <QGraphicsScene>

#include "networkscanner.h"
#include "networktopology.h"
#include "deviceanalyzer.h"
#include "scanhistory.h"

// QtCharts命名空间已经在deviceanalyzer.h中引入
// using namespace QtCharts;

/**
 * @class MainWindow
 * @brief 主窗口类，负责程序的主要界面和交互逻辑。
 */
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    /**
     * @brief MainWindow 构造函数
     * @param parent 父控件指针
     */
    MainWindow(QWidget *parent = nullptr);
    /**
     * @brief MainWindow 析构函数
     */
    ~MainWindow();

private slots:
    /** @brief 开始扫描 */
    void startScan();
    /** @brief 停止扫描 */
    void stopScan();
    /**
     * @brief 当发现一个主机时调用
     * @param host 发现的主机信息
     */
    void onHostFound(const HostInfo &host);
    /** @brief 当扫描开始时调用 */
    void onScanStarted();
    /** @brief 当扫描结束时调用 */
    void onScanFinished();
    /**
     * @brief 当扫描进度更新时调用
     * @param progress 扫描进度 (0-100)
     */
    void onScanProgress(int progress);
    /**
     * @brief 当扫描发生错误时调用
     * @param errorMessage 错误信息
     */
    void onScanError(const QString &errorMessage);
    
    // 现有功能槽
    /** @brief 保存扫描结果 */
    void saveResults();
    /** @brief 清除扫描结果 */
    void clearResults();
    /** @brief 显示设置界面 */
    void showSettings();
    /** @brief 应用设置 */
    void applySettings();
    /** @brief 显示关于对话框 */
    void showAbout();
    /**
     * @brief 显示主机详细信息
     * @param row 表格中的行号
     * @param column 表格中的列号
     */
    void showHostDetails(int row, int column);
    /** @brief 导出结果为CSV文件 */
    void exportToCSV();
    /**
     * @brief 切换自定义端口扫描选项的可用状态
     * @param checked 是否选中
     */
    void togglePortScanOptions(bool checked);
    /**
     * @brief 切换自定义IP范围选项的可用状态
     * @param checked 是否选中
     */
    void toggleRangeOptions(bool checked);
    
    // 新增功能槽
    /** @brief 显示网络拓扑视图 */
    void showTopologyView();
    /** @brief 显示统计分析视图 */
    void showStatisticsView();
    /** @brief 显示扫描历史视图 */
    void showHistoryView();
    /** @brief 生成安全报告 */
    void generateSecurityReport();
    /** @brief 保存网络拓扑图为图片 */
    void saveTopologyImage();
    /**
     * @brief 切换暗色模式
     * @param enable 是否启用暗色模式
     */
    void toggleDarkMode(bool enable);
    /** @brief 比较扫描结果 */
    void compareScanResults();
    /** @brief 计划扫描 */
    void scheduleScan();
    /** @brief 保存扫描历史到文件 */
    void saveHistoryToFile();
    /** @brief 从文件加载扫描历史 */
    void loadHistoryFromFile();
    /** @brief 更新网络拓扑图 */
    void updateNetworkTopology();
    /** @brief 刷新网络拓扑图 */
    void refreshTopology();
    /** @brief 过滤扫描结果 */
    void filterResults();
    /** @brief 清除过滤器 */
    void clearFilters();
    /** @brief 当主题改变时调用 */
    void onThemeChanged();

private:
    /** @brief 创建用户界面 */
    void createUI();
    /** @brief 创建菜单 */
    void createMenus();
    /** @brief 创建设置对话框 */
    void createSettingsDialog();
    /** @brief 创建网络拓扑标签页 */
    void createTopologyTab();
    /** @brief 创建统计分析标签页 */
    void createStatisticsTab();
    /** @brief 创建扫描历史标签页 */
    void createHistoryTab();
    /** @brief 创建主机详情标签页 */
    void createDetailsTab();
    /** @brief 创建安全相关标签页 (如果需要) */
    void createSecurityTab(); // TODO: 根据实际需求决定是否实现
    /** @brief 设置信号和槽的连接 */
    void setupConnections();
    /** @brief 更新端口列表 (如果需要) */
    void updatePortsList(); // TODO: 根据实际需求决定是否实现
    /** @brief 加载程序设置 */
    void loadSettings();
    /** @brief 保存程序设置 */
    void saveSettings();
    /** @brief 更新统计数据 */
    void updateStatistics();
    /**
     * @brief 应用主题（暗色/浅色）
     * @param darkMode 是否应用暗色模式
     */
    void applyTheme(bool darkMode);
    
    // UI元素
    QWidget *m_centralWidget;          ///< 中央控件
    QTabWidget *m_tabWidget;           ///< 标签页控件
    
    // 扫描结果标签页
    QWidget *m_scanTab;                ///< 扫描结果标签页
    QVBoxLayout *m_mainLayout;         ///< 主布局（扫描结果页）
    QHBoxLayout *m_controlLayout;      ///< 控制按钮布局
    QTableWidget *m_resultsTable;      ///< 扫描结果表格
    QPushButton *m_scanButton;         ///< 开始扫描按钮
    QPushButton *m_stopButton;         ///< 停止扫描按钮
    QPushButton *m_clearButton;        ///< 清除结果按钮
    QPushButton *m_saveButton;         ///< 保存结果按钮
    QProgressBar *m_progressBar;       ///< 扫描进度条
    QLabel *m_statusLabel;             ///< 状态标签
    QStatusBar *m_statusBar;           ///< 状态栏
    
    // 扫描设置标签页
    QWidget *m_settingsTab;            ///< 扫描设置标签页
    QVBoxLayout *m_settingsLayout;     ///< 设置标签页布局
    
    // 端口设置区域
    QGroupBox *m_portsGroupBox;        ///< 端口设置组
    QCheckBox *m_customPortsCheckBox;  ///< 自定义端口复选框
    QLineEdit *m_portsLineEdit;        ///< 端口输入框
    QSpinBox *m_timeoutSpinBox;        ///< 超时时间设置框
    
    // IP范围设置区域
    QGroupBox *m_rangeGroupBox;        ///< IP范围设置组
    QCheckBox *m_customRangeCheckBox;  ///< 自定义IP范围复选框
    QLineEdit *m_startIPLineEdit;      ///< 起始IP输入框
    QLineEdit *m_endIPLineEdit;        ///< 结束IP输入框
    
    // 主机详情标签页
    QWidget *m_detailsTab;             ///< 主机详情标签页
    QVBoxLayout *m_detailsLayout;      ///< 主机详情页布局
    QTextEdit *m_detailsTextEdit;      ///< 主机详情文本框
    
    // 网络拓扑标签页
    QWidget *m_topologyTab;            ///< 网络拓扑标签页
    NetworkTopology *m_networkTopology;  ///< 网络拓扑控件
    
    // 统计分析标签页
    QWidget *m_statisticsTab;          ///< 统计分析标签页
    DeviceAnalyzer *m_deviceAnalyzer;  ///< 设备分析器
    QChartView *m_deviceTypeChartView; ///< 设备类型图表视图
    QChartView *m_vendorChartView;     ///< 厂商分布图表视图
    QChartView *m_portDistributionChartView; ///< 端口分布图表视图
    QTextEdit *m_securityReportText;   ///< 安全报告文本框
    
    // 扫描历史标签页
    QWidget *m_historyTab;             ///< 扫描历史标签页
    ScanHistory *m_scanHistory;        ///< 扫描历史管理器
    QComboBox *m_sessionComboBox;      ///< 扫描会话选择框
    QTableWidget *m_historyTable;      ///< 扫描历史表格
    
    // 菜单项
    QMenu *m_fileMenu;                 ///< 文件菜单
    QMenu *m_viewMenu;                 ///< 视图菜单
    QMenu *m_toolsMenu;                ///< 工具菜单
    QMenu *m_helpMenu;                 ///< 帮助菜单
    QAction *m_exportAction;           ///< 导出结果动作
    QAction *m_saveHistoryAction;      ///< 保存扫描历史动作
    QAction *m_loadHistoryAction;      ///< 加载扫描历史动作
    QAction *m_saveTopologyAction;     ///< 保存网络拓扑图动作
    QAction *m_exitAction;             ///< 退出动作
    QAction *m_settingsAction;         ///< 设置动作
    QAction *m_darkModeAction;         ///< 暗色模式动作
    QAction *m_scheduleScanAction;     ///< 计划扫描动作
    QAction *m_aboutAction;            ///< 关于动作
    
    // 过滤控件
    QWidget *m_filterWidget;           ///< 过滤控件容器
    QLineEdit *m_filterIPLineEdit;     ///< IP过滤输入框
    QComboBox *m_filterVendorComboBox; ///< 厂商过滤选择框
    QComboBox *m_filterTypeComboBox;   ///< 设备类型过滤选择框
    QPushButton *m_filterButton;       ///< 应用过滤按钮
    QPushButton *m_clearFilterButton;  ///< 清除过滤按钮
    
    // 网络扫描器
    NetworkScanner *m_scanner;         ///< 网络扫描器实例

    // 扫描的主机数量
    int m_hostsFound;                  ///< 已发现的主机数量
    
    // 当前查看的主机索引
    int m_currentHostIndex;            ///< 当前结果表格中选中的主机索引 (可能已废弃)
    
    // 主题设置
    bool m_darkModeEnabled;            ///< 是否启用暗色模式
};

#endif // MAINWINDOW_H 