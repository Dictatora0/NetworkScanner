#ifndef NETWORKTOPOLOGY_H
#define NETWORKTOPOLOGY_H

#include <QWidget>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QGraphicsItem>
#include <QMap>
#include <QPair>
#include <QProcess>
#include "networkscanner.h"

/** @enum DeviceType
 *  @brief 定义网络中可能出现的设备类型。
 */
enum DeviceType {
    DEVICE_UNKNOWN, ///< 未知设备类型
    DEVICE_ROUTER,  ///< 路由器
    DEVICE_SERVER,  ///< 服务器
    DEVICE_PC,      ///< 个人电脑
    DEVICE_MOBILE,  ///< 移动设备 (手机、平板等)
    DEVICE_PRINTER, ///< 网络打印机
    DEVICE_IOT      ///< 物联网设备 (智能家居等)
};

/** @enum ConnectionType
 *  @brief 定义设备之间的连接类型。
 */
enum ConnectionType {
    CONNECTION_UNKNOWN, ///< 未知连接类型
    CONNECTION_DIRECT,  ///< 直接物理连接 (例如，以太网)
    CONNECTION_WIRELESS,///< 无线连接 (例如，Wi-Fi)
    CONNECTION_VPN,     ///< VPN 连接
    CONNECTION_ROUTED   ///< 通过一个或多个路由器间接连接
};

/**
 * @class TopologyAnalyzer
 * @brief 网络拓扑分析器类。
 * @details 提供一系列方法来分析主机列表，推断设备间的连接关系、
 *          网络层次结构、子网结构，并进行设备聚类。
 */
class TopologyAnalyzer {
public:
    /**
     * @brief TopologyAnalyzer 构造函数。
     */
    TopologyAnalyzer();
    
    /**
     * @brief 根据主机信息推断设备之间的连接关系。
     * @param hosts 包含网络中所有主机信息的列表。
     * @return 一个映射表，键为源设备IP，值为目标设备IP列表，表示它们之间的连接。
     * @details 连接关系可能基于网关信息、TTL层级和子网分析。
     */
    QMap<QString, QStringList> inferDeviceConnections(const QList<HostInfo> &hosts);
    
    /**
     * @brief 分析网络中设备的TTL（Time To Live）层次结构。
     * @param hosts 主机信息列表。
     * @return 一个映射表，键为TTL层级（整数），值为该层级下的设备IP列表。
     * @details 通常网关在第0层，直连设备在第1层，依此类推。TTL值通过ping获取。
     */
    QMap<int, QStringList> analyzeTTLLayers(const QList<HostInfo> &hosts);
    
    /**
     * @brief 分析网络中的子网结构。
     * @param hosts 主机信息列表。
     * @return 一个映射表，键为子网地址 (如 "192.168.1.0")，值为该子网下的设备IP列表。
     */
    QMap<QString, QStringList> analyzeSubnets(const QList<HostInfo> &hosts);
    
    /**
     * @brief 基于设备响应时间对设备进行聚类。
     * @param hosts 主机信息列表。
     * @return 一个包含多个设备IP列表的列表，每个内部列表代表一个聚类。
     * @details 例如，可以分为本地设备、近端设备、远端设备等。
     */
    QList<QStringList> clusterDevicesByResponseTime(const QList<HostInfo> &hosts);
    
    /**
     * @brief 获取特定IP地址的TTL值。
     * @param ipAddress 目标IP地址字符串。
     * @return TTL值。如果无法获取，则返回-1。根据操作系统执行ping命令解析TTL。
     */
    int getTTLValue(const QString &ipAddress);
    
    /**
     * @brief 执行traceroute命令获取到目标IP的路径信息。
     * @param targetIP 目标IP地址字符串。
     * @return 一个包含路径上各跳IP地址的字符串列表。
     * @details 根据操作系统执行traceroute或tracert命令。
     */
    QStringList performTraceRoute(const QString &targetIP);
    
    /**
     * @brief 计算给定IP地址所属的子网地址。
     * @param ip IP地址字符串。
     * @param prefixLength 子网前缀长度 (例如，对于255.255.255.0，为24)。默认为24。
     * @return 子网地址字符串 (例如 "192.168.1.0")。如果IP格式无效则返回空字符串。
     */
    QString calculateSubnet(const QString &ip, int prefixLength = 24);
    
    /**
     * @brief 判断两个IP地址是否在同一个子网中。
     * @param ip1 第一个IP地址字符串。
     * @param ip2 第二个IP地址字符串。
     * @param prefixLength 子网前缀长度。默认为24。
     * @return 如果在同一子网则返回 true，否则返回 false。
     */
    bool inSameSubnet(const QString &ip1, const QString &ip2, int prefixLength = 24);
    
private:
    // 已移除private中的calculateSubnet声明
};

/**
 * @class DeviceNode
 * @brief 代表网络拓扑图中的一个设备节点，继承自 QGraphicsItem。
 * @details 负责绘制设备图标、显示IP地址，并处理用户交互 (如拖动、悬停提示)。
 */
class DeviceNode : public QGraphicsItem
{
public:
    /**
     * @brief DeviceNode 构造函数。
     * @param host 该节点代表的主机信息。
     * @param type 该节点的设备类型，默认为 DEVICE_UNKNOWN。
     */
    DeviceNode(const HostInfo &host, DeviceType type = DEVICE_UNKNOWN);
    
    /**
     * @brief 返回节点的边界矩形。
     * @return QRectF 边界矩形。
     */
    QRectF boundingRect() const override;
    /**
     * @brief 绘制设备节点。
     * @param painter QPainter 指针。
     * @param option QStyleOptionGraphicsItem 指针。
     * @param widget QWidget 指针 (关联的视图)。
     * @details 根据设备类型绘制不同颜色和图标的圆形节点，并显示IP地址。
     *          选中或高亮时颜色会变化。
     */
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) override;
    
    /**
     * @brief 设置节点的设备类型。
     * @param type 新的设备类型。
     */
    void setDeviceType(DeviceType type);
    /**
     * @brief 获取节点的设备类型。
     * @return DeviceType 设备类型。
     */
    DeviceType deviceType() const { return m_type; }
    
    /**
     * @brief 获取节点的IP地址。
     * @return QString IP地址字符串。
     */
    QString ipAddress() const { return m_host.ipAddress; }
    /**
     * @brief 获取节点关联的完整主机信息。
     * @return HostInfo 主机信息结构体。
     */
    HostInfo hostInfo() const { return m_host; }
    /**
     * @brief 设置节点的位置 (已废弃，QGraphicsItem自带 setPos)。
     * @param pos 新的位置坐标。
     */
    void setPosition(const QPointF &pos);
    
    // 新增：设置网络层级
    /**
     * @brief 设置节点的网络层级 (例如，基于TTL)。
     * @param layer 网络层级整数。
     */
    void setNetworkLayer(int layer) { m_networkLayer = layer; }
    /**
     * @brief 获取节点的网络层级。
     * @return int 网络层级。
     */
    int networkLayer() const { return m_networkLayer; }
    
    // 新增：设置子网组
    /**
     * @brief 设置节点所属的子网组。
     * @param subnet 子网地址字符串。
     */
    void setSubnetGroup(const QString &subnet) { m_subnetGroup = subnet; }
    /**
     * @brief 获取节点所属的子网组。
     * @return QString 子网地址字符串。
     */
    QString subnetGroup() const { return m_subnetGroup; }
    
protected:
    void mousePressEvent(QGraphicsSceneMouseEvent *event) override;
    void mouseMoveEvent(QGraphicsSceneMouseEvent *event) override;
    void mouseReleaseEvent(QGraphicsSceneMouseEvent *event) override;
    void hoverEnterEvent(QGraphicsSceneHoverEvent *event) override;
    void hoverLeaveEvent(QGraphicsSceneHoverEvent *event) override;
    
private:
    HostInfo m_host;      ///< 节点关联的主机信息
    DeviceType m_type;    ///< 节点的设备类型
    bool m_highlight;     ///< 节点是否高亮 (鼠标悬停)
    QPointF m_dragStartPosition; ///< 拖动开始时的位置
    int m_networkLayer;   ///< 节点的网络层级 (用于布局)
    QString m_subnetGroup;///< 节点所属的子网组 (用于布局)
};

/**
 * @class ConnectionLine
 * @brief 代表网络拓扑图中两个设备节点之间的连接线，继承自 QGraphicsItem。
 * @details 负责绘制连接线，并根据连接类型 (直接、无线、VPN、路由) 显示不同样式。
 */
class ConnectionLine : public QGraphicsItem
{
public:
    /**
     * @brief ConnectionLine 构造函数。
     * @param source 源设备节点指针。
     * @param target 目标设备节点指针。
     * @param type 连接类型，默认为 CONNECTION_DIRECT。
     */
    ConnectionLine(DeviceNode *source, DeviceNode *target, 
                  ConnectionType type = CONNECTION_DIRECT);
    
    QRectF boundingRect() const override;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) override;
    
    /**
     * @brief 更新连接线的位置 (当连接的节点移动时调用)。
     */
    void updatePosition();
    
    /**
     * @brief 设置连接线的类型。
     * @param type 新的连接类型。
     */
    void setConnectionType(ConnectionType type);
    /**
     * @brief 获取连接线的类型。
     * @return ConnectionType 连接类型。
     */
    ConnectionType connectionType() const { return m_connectionType; }
    
private:
    DeviceNode *m_source;         ///< 源设备节点
    DeviceNode *m_target;         ///< 目标设备节点
    ConnectionType m_connectionType; ///< 连接类型
};

/**
 * @class NetworkTopologyView
 * @brief 网络拓扑图的视图类，继承自 QGraphicsView。
 * @details 负责显示 DeviceNode 和 ConnectionLine 对象，提供缩放、拖动等交互功能，
 *          并实现不同的布局算法 (如层次布局、分组布局)。
 */
class NetworkTopologyView : public QGraphicsView
{
    Q_OBJECT
    
public:
    /**
     * @brief NetworkTopologyView 构造函数。
     * @param parent 父控件指针。
     */
    NetworkTopologyView(QWidget *parent = nullptr);
    
    /**
     * @brief 设置要在拓扑图中显示的主机列表。
     * @param hosts 主机信息列表。
     * @details 此方法会清除现有节点和连接，然后根据新的主机列表创建拓扑图。
     */
    void setHosts(const QList<HostInfo> &hosts);
    /**
     * @brief 清除拓扑图中的所有节点和连接。
     */
    void clear();
    /**
     * @brief 应用自动布局算法重新排列节点。
     */
    void autoLayout();
    
    /**
     * @brief 应用层次化布局算法。
     * @param layers 一个映射表，键为层级，值为该层级下的设备IP列表。
     */
    void hierarchicalLayout(const QMap<int, QStringList> &layers);
    /**
     * @brief 应用分组布局算法。
     * @param groups 一个映射表，键为组名/ID，值为该组下的设备IP列表。
     */
    void groupedLayout(const QMap<QString, QStringList> &groups);
    
signals:
    /**
     * @brief 当用户在拓扑图中选择一个设备节点时发出此信号。
     * @param host被选节点的 HostInfo。
     */
    void nodeSelected(const HostInfo &host);
    
private:
    QGraphicsScene *m_scene;                ///< QGraphicsScene 用于管理图形项
    QMap<QString, DeviceNode*> m_nodes;     ///< IP地址到DeviceNode指针的映射
    QList<ConnectionLine*> m_connections;   ///< 存储所有连接线的列表
    
    TopologyAnalyzer m_analyzer;            ///<拓扑分析器实例
    
    /**
     * @brief 根据主机信息推断设备类型。
     * @param host 主机信息。
     * @return DeviceType 推断出的设备类型。
     */
    DeviceType determineDeviceType(const HostInfo &host);
    /**
     * @brief 创建两个设备节点之间的连接线。
     * @param source 源设备节点指针。
     * @param target 目标设备节点指针。
     * @param type 连接类型，默认为 CONNECTION_DIRECT。
     */
    void createConnection(DeviceNode *source, DeviceNode *target, 
                          ConnectionType type = CONNECTION_DIRECT);
};

/**
 * @class NetworkTopology
 * @brief 网络拓扑组件的主控件，继承自 QWidget。
 * @details 包含 NetworkTopologyView (用于显示拓扑图) 和一个控制面板 (用于布局切换、缩放等操作)。
 */
class NetworkTopology : public QWidget
{
    Q_OBJECT
    
public:
    /**
     * @brief NetworkTopology 构造函数。
     * @param parent 父控件指针。
     */
    NetworkTopology(QWidget *parent = nullptr);
    
    /**
     * @brief 更新拓扑图显示的主机列表。
     * @param hosts 新的主机信息列表。
     */
    void updateTopology(const QList<HostInfo> &hosts);
    /**
     * @brief 清除当前显示的拓扑图。
     */
    void clear();
    
    /**
     * @brief 缩放拓扑图视图。
     * @param factor 缩放因子 (例如，1.2 表示放大，0.8 表示缩小)。
     */
    void scale(qreal factor);
    /**
     * @brief 重置拓扑图视图，使其适应所有节点。
     */
    void resetView();
    
    /**
     * @brief 设置拓扑图的布局模式。
     * @param mode 布局模式枚举值 (LayoutMode)。
     */
    void setLayoutMode(int mode);
    
signals:
    /**
     * @brief 当用户在拓扑图中选择一个设备时发出此信号 (从 NetworkTopologyView 转发)。
     * @param host 被选设备的 HostInfo。
     */
    void deviceSelected(const HostInfo &host);
    
private:
    NetworkTopologyView *m_topologyView; ///< 拓扑图视图控件
    QWidget *m_controlPanel;             ///< 控制面板控件
    
    /** @enum LayoutMode
     *  @brief 定义支持的布局模式。
     */
    enum LayoutMode {
        LAYOUT_AUTO,         ///< 自动布局
        LAYOUT_HIERARCHICAL, ///< 层次化布局
        LAYOUT_GROUPED       ///< 分组布局
    };
    
    LayoutMode m_layoutMode;        ///< 当前选定的布局模式
    QList<HostInfo> m_currentHosts; ///< 缓存当前主机列表，用于布局切换时重新应用
};

#endif // NETWORKTOPOLOGY_H 