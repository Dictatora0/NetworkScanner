//
// networkscanner.h
//

/**
 * @file networkscanner.h
 * @brief 网络扫描器类定义
 * @details 提供网络设备发现和端口扫描功能
 * @author Network Scanner Team
 * @version 2.1.0
 */

#ifndef NETWORKSCANNER_H
#define NETWORKSCANNER_H

#include <QObject>
#include <QHostAddress>
#include <QList>
#include <QMap>
#include <QMutex>
#include <QTcpSocket>
#include <QDateTime>
#include <QNetworkInterface>
#include <QFuture>
#include <QtConcurrent/QtConcurrent>
#include <QHostInfo>
#include <QThreadPool>
#include <QRunnable>
#include <QElapsedTimer>
#include <QSemaphore>

/**
 * @struct HostInfo
 * @brief 存储主机信息的结构体
 * @details 包含IP地址、主机名、MAC地址、厂商信息等扫描结果
 */
struct HostInfo {
    QString ipAddress;   ///< 主机IP地址
    QString hostName;    ///< 主机名称
    QString macAddress;  ///< MAC物理地址
    QString macVendor;   ///< MAC地址对应的厂商
    bool isReachable;    ///< 主机是否可达
    QDateTime scanTime;  ///< 扫描时间
    QMap<int, bool> openPorts; ///< 开放的端口及状态 (端口号 -> 是否开放)
};

/**
 * @enum ScanMode
 * @brief 扫描模式枚举 (旧的，建议使用 ScanStrategy::ScanMode)
 */
enum ScanMode {
    QUICK,      ///< 快速扫描
    STANDARD,   ///< 标准扫描
    THOROUGH    ///< 彻底扫描
};

/**
 * @class ScanStrategy
 * @brief 扫描策略类
 * @details 定义不同的扫描模式和参数，如快速扫描、标准扫描和深度扫描
 */
class ScanStrategy {
public:
    /**
     * @enum ScanMode
     * @brief 扫描模式枚举
     */
    enum ScanMode {
        QUICK_SCAN,      ///< 仅检测主机存活
        STANDARD_SCAN,   ///< 扫描常用端口
        DEEP_SCAN        ///< 全面端口扫描
    };
    
    /**
     * @brief 构造函数
     * @param mode 扫描模式，默认为标准扫描
     */
    ScanStrategy(ScanMode mode = STANDARD_SCAN);
    
    /**
     * @brief 获取要扫描的端口列表
     * @return 端口号列表
     */
    QList<int> getPortsToScan() const;
    
    /**
     * @brief 获取扫描超时时间
     * @param ip 目标IP地址
     * @return 超时时间（毫秒）
     */
    int getScanTimeout(const QString &ip) const;
    
    /**
     * @brief 获取最大并行任务数
     * @return 并行任务数量
     */
    int getMaxParallelTasks() const;
    
    /**
     * @brief 更新主机响应时间记录
     * @param ip 主机IP地址
     * @param responseTime 响应时间（毫秒）
     */
    void updateHostResponseTime(const QString &ip, int responseTime);
    
    /**
     * @brief 获取当前扫描模式
     * @return 扫描模式
     */
    ScanMode getMode() const { return m_mode; }
    
    /**
     * @brief 设置扫描模式
     * @param mode 要设置的扫描模式
     */
    void setMode(ScanMode mode) { m_mode = mode; }
    
private:
    ScanMode m_mode;  ///< 当前扫描模式
    QMap<QString, int> m_hostResponseTimes;  ///< IP地址 -> 响应时间映射
};

/**
 * @class ScanTask
 * @brief 扫描任务类
 * @details 用于并行执行的单个主机扫描任务, 继承自 QRunnable 以便在线程池中运行。
 */
class ScanTask : public QRunnable {
public:
    /**
     * @brief 构造函数
     * @param parent 父对象 (通常是 NetworkScanner 实例)
     * @param address 要扫描的地址
     * @param ports 要扫描的端口列表
     * @param timeout 连接超时时间（毫秒）
     */
    ScanTask(QObject* parent, const QHostAddress &address, 
             const QList<int> &ports, int timeout);
    
    /**
     * @brief 执行扫描任务
     * @details 实现QRunnable的抽象方法，在此方法中执行实际的扫描逻辑。
     */
    void run() override;
    
    QObject* m_parent;          ///< 父对象指针 (NetworkScanner)
    QHostAddress m_address;     ///< 扫描目标IP地址
    QList<int> m_ports;         ///< 待扫描的端口列表
    int m_timeout;              ///< 单个端口连接超时时间 (毫秒)
};

/**
 * @class NetworkScanner
 * @brief 网络扫描器类
 * @details 提供网络设备发现和端口扫描功能，支持多种扫描策略和并发处理。
 */
class NetworkScanner : public QObject
{
    Q_OBJECT
    
public:
    /**
     * @brief 构造函数
     * @param parent 父对象指针
     */
    explicit NetworkScanner(QObject *parent = nullptr);
    
    /**
     * @brief 析构函数
     * @details 停止任何正在进行的扫描并清理资源。
     */
    ~NetworkScanner();
    
    /**
     * @brief 设置自定义端口扫描列表
     * @param ports 要扫描的端口列表。如果扫描正在进行，此设置无效。
     */
    void setCustomPortsToScan(const QList<int> &ports);
    
    /**
     * @brief 设置扫描超时时间
     * @param msecs 超时时间(毫秒)。如果扫描正在进行，此设置无效。
     */
    void setScanTimeout(int msecs);
    
    /**
     * @brief 设置自定义IP范围进行扫描
     * @param startIP 起始IP地址 (例如 "192.168.1.1")
     * @param endIP 结束IP地址 (例如 "192.168.1.254")
     * @details 如果扫描正在进行，此设置无效。
     */
    void setCustomIPRange(const QString &startIP, const QString &endIP);
    
    /**
     * @brief 设置扫描策略
     * @param mode 要使用的扫描模式 (快速, 标准, 深度)
     */
    void setScanStrategy(ScanStrategy::ScanMode mode);
    
    /**
     * @brief 获取当前扫描到的所有主机信息
     * @return 包含所有已发现主机信息的列表
     */
    QList<HostInfo> getScannedHosts() const;
    
    /**
     * @brief 将当前扫描结果保存到CSV文件
     * @param filename 要保存的文件名
     */
    void saveResultsToFile(const QString &filename) const;
    
    /**
     * @brief 开始网络扫描
     * @details 根据当前设置 (IP范围、端口、策略等) 启动扫描过程。
     *          会触发 scanStarted() 信号。
     */
    void startScan();
    
    /**
     * @brief 停止当前正在进行的扫描
     * @details 会尝试终止所有扫描任务和相关进程，并触发 scanFinished() 信号。
     */
    void stopScan();
    
    /**
     * @brief 检查扫描器当前是否正在扫描
     * @return 如果正在扫描则返回 true，否则返回 false
     */
    bool isScanning() const;
    
    /**
     * @brief 快速Ping扫描方法 (可能已废弃或内部使用)
     * @param addresses 要扫描的地址列表
     * @return 活跃的主机地址列表
     */
    QList<QHostAddress> quickPingScan(const QList<QHostAddress> &addresses);
    
    /**
     * @brief 检查单个主机是否可达 (可能已废弃或内部使用)
     * @param address 主机地址
     * @param timeout 超时时间(毫秒)
     * @return 主机是否可达
     */
    bool isHostReachable(const QHostAddress &address, int timeout);
    
    /**
     * @brief 检查主机在多个端口上是否可达 (可能已废弃或内部使用)
     * @param address 主机地址
     * @param ports 端口列表
     * @param timeout 超时时间(毫秒)
     * @return 是否至少有一个端口可达
     */
    bool isReachableOnPorts(const QHostAddress &address, const QList<int> &ports, int timeout);
    
    /**
     * @brief 扫描单个主机 (主要内部扫描逻辑调用)
     * @param address 要扫描的主机IP地址
     */
    void scanHost(const QHostAddress &address);
    
    /**
     * @brief 查询指定IP地址的主机名
     * @param address 主机IP地址
     * @return 主机名，如果无法解析则返回IP地址或"未知主机"
     */
    QString lookupHostName(const QHostAddress &address);
    
    /**
     * @brief 查询指定IP地址的MAC地址
     * @param address 主机IP地址
     * @return MAC地址，如果无法获取则返回"未知"或伪MAC地址
     */
    QString lookupMacAddress(const QHostAddress &address);
    
    /**
     * @brief 根据MAC地址查询对应的硬件厂商
     * @param macAddress MAC地址 (通常为前6位OUI)
     * @return 厂商名称，如果未知则返回"未知厂商"
     */
    QString lookupMacVendor(const QString &macAddress);
    
    /**
     * @brief 根据IP地址生成一个伪MAC地址 (用于无法获取真实MAC的情况)
     * @param ip IP地址
     * @return 生成的伪MAC地址，格式如 "SM:XX:XX:XX:XX"
     */
    QString generatePseudoMACFromIP(const QString &ip);
    
    /**
     * @brief 设置扫描模式 (旧的，建议使用 setScanStrategy)
     * @param mode 要设置的扫描模式
     */
    void setScanMode(ScanMode mode) { m_scanMode = mode; }
    
    /**
     * @brief 设置是否启用调试模式
     * @param debug 如果为 true，则启用调试输出
     */
    void setDebugMode(bool debug) { m_debugMode = debug; }
    
    /**
     * @brief 设置是否启用随机化扫描IP顺序
     * @param randomize 如果为 true，则打乱IP扫描顺序
     */
    void setRandomizeScan(bool randomize) { m_randomizeScan = randomize; }
    
    /**
     * @brief 检查主机是否可达 (具体实现，可能调用pingHost)
     * @param address 主机地址
     * @param timeout 超时时间(毫秒)
     * @return 主机是否可达
     */
    bool checkHostReachable(const QHostAddress &address, int timeout);
    
signals:
    /**
     * @brief 当发现一个可达或不可达的主机时发出此信号
     * @param host 包含主机信息的 HostInfo 结构体
     */
    void hostFound(const HostInfo &host);
    
    /**
     * @brief 当扫描过程开始时发出此信号
     */
    void scanStarted();
    
    /**
     * @brief 当扫描过程（正常或异常）结束时发出此信号
     */
    void scanFinished();
    
    /**
     * @brief 扫描进度更新信号
     * @param progress 当前扫描进度百分比 (0-100)
     */
    void scanProgress(int progress);
    
    /**
     * @brief 当扫描过程中发生错误时发出此信号
     * @param errorMessage 描述错误的字符串
     */
    void scanError(const QString &errorMessage);
    
public slots:
    /**
     * @brief 处理一个扫描任务完成的槽函数 (由 ScanTask 调用)
     * @param hostInfo 扫描到的主机信息
     */
    void onScanTaskFinished(const HostInfo &hostInfo);
    
    /**
     * @brief 更新整体扫描进度的槽函数
     */
    void updateScanProgress();
    
    /**
     * @brief 当异步主机名查询完成后调用的槽函数
     * @param hostInfo QHostInfo 对象，包含查询结果
     */
    void onHostNameLookedUp(const QHostInfo &hostInfo);
    
private:
    /**
     * @brief 获取本机所有活动的、非环回的网络接口的IP地址列表
     * @return IP地址列表 (QHostAddress)
     */
    QList<QHostAddress> getLocalNetworkAddresses();
    
    /**
     * @brief 将MAC地址规范化为标准格式 (XX:XX:XX:XX:XX:XX)
     * @param macAddress 原始MAC地址字符串
     * @return 规范化后的MAC地址，如果无法规范化则返回原始或"未知"
     */
    QString normalizeMacAddress(const QString &macAddress);
    
    /**
     * @brief 使用ping命令检测目标主机是否可达，并指定超时
     * @param ip 目标IP地址字符串
     * @param timeout ping命令的超时时间 (毫秒)
     * @return 如果主机可达则返回 true，否则返回 false
     */
    bool pingTargetWithTimeout(const QString &ip, int timeout);
    
    /**
     * @brief 通过系统调用 (如 arp -a) 获取指定IP的MAC地址 (可能平台相关且不可靠)
     * @param ip 目标IP地址字符串
     * @return MAC地址字符串，如果无法获取则为空
     */
    QString getMacAddressFromSystemCalls(const QString &ip);
    
    /**
     * @brief 执行ARP扫描以获取本地网络设备的MAC地址 (可能平台相关且不可靠)
     * @return IP地址和MAC地址对的列表
     */
    QList<QPair<QHostAddress, QString>> performARPScan();
    
    /**
     * @brief 扫描指定主机的端口列表
     * @param hostInfo 要更新端口信息的主机结构体 (会被修改)
     */
    void scanHostPorts(HostInfo &hostInfo);
    
    /**
     * @brief 根据当前配置获取将要扫描的IP地址列表
     * @return IP地址列表
     */
    QList<QHostAddress> getAddressesToScan();
    
    /**
     * @brief 定期处理和汇总扫描结果，更新进度，判断扫描是否完成
     */
    void processScanResults();
    
    /** @brief 终止所有正在运行的ping进程 (尝试优雅终止) */
    void terminateAllPingProcesses();
    /** @brief 强制终止所有正在运行的ping进程 (kill -9) */
    void forceKillAllPingProcesses();
    
    bool m_isScanning;  ///< 标记当前是否正在扫描
    
    int m_scannedHosts;  ///< 当前已扫描的主机数量 (用于进度计算)
    int m_totalHosts;    ///< 本次扫描总共需要扫描的主机数量
    int m_scanTimeout;   ///< 单个端口或ping操作的超时时间 (毫秒)
    
    bool m_useCustomRange;       ///< 是否使用用户自定义的IP范围
    QHostAddress m_startIPRange; ///< 自定义扫描的起始IP地址
    QHostAddress m_endIPRange;   ///< 自定义扫描的结束IP地址
    
    QList<int> m_portsToScan;  ///< 当前配置的待扫描端口列表
    
    QList<HostInfo> m_scannedHostsList;  ///< 存储所有扫描到的主机信息 (包括可达和不可达)
    QMutex m_mutex;  ///< 用于保护 m_scannedHostsList 和 m_scannedHosts 等共享数据的互斥锁
    
    QList<QFuture<void>> m_scanFutures;  ///< 存储QtConcurrent::run返回的QFuture对象，用于跟踪异步任务
    QThreadPool m_threadPool;  ///< 自定义线程池，用于执行扫描任务
    
    QMap<QString, QString> m_macAddressCache;  ///< MAC地址缓存 (IP -> MAC)，避免重复查询
    
    ScanStrategy m_scanStrategy;  ///< 当前使用的扫描策略对象
    
    QList<QHostAddress> m_activeHosts;  ///< 存储快速Ping扫描发现的活跃主机 (可能已废弃)
    
    ScanMode m_scanMode;     ///< 当前扫描模式 (旧的，应优先使用 m_scanStrategy.getMode())
    bool m_debugMode;        ///< 是否启用调试模式，控制详细日志输出
    bool m_randomizeScan;    ///< 是否随机化IP地址扫描顺序
    
    QElapsedTimer m_scanStartTime;  ///< 记录本次扫描开始的时间，用于计算总耗时
    QDateTime m_lastProgressUpdate; ///< 上一次进度更新的时间，用于控制进度更新频率
    
    /**
     * @brief 辅助函数：执行外部进程并获取其输出 (已标记为静态，但可能不应为静态如果需要访问成员)
     * @param program 要执行的程序名或路径
     * @param args 传递给程序的参数列表
     * @param stdOutOutput 用于接收标准输出的字符串引用
     * @param stdErrOutput 用于接收标准错误的字符串引用
     * @param startTimeout 等待进程启动的超时时间 (毫秒)
     * @param finishTimeout 等待进程完成的超时时间 (毫秒)
     * @return 如果进程成功执行并退出则返回 true，否则返回 false
     * @note 此方法已被重构为不再实际执行外部进程，以提高稳定性。
     */
    static bool executeProcess(const QString &program, const QStringList &args, QString &stdOutOutput, QString &stdErrOutput, int startTimeout = 2000, int finishTimeout = 5000);
    
    QSemaphore* m_pingSemaphore;       ///< 控制并发ping进程数量的信号量
    const int m_maxConcurrentPings = 8; ///< 最大并发ping任务数量 (已从15减少)

    // 新增的负责ping操作的方法
    /**
     * @brief 使用系统ping命令检查主机是否可达，具有超时控制。
     * @param ipAddress 目标主机的IP地址字符串。
     * @param timeoutMs ping操作的超时时间（毫秒），默认为1500ms。
     * @return 如果主机在超时时间内响应ping，则返回true；否则返回false。
     * @note 此方法会尝试获取 m_pingSemaphore 信号量以控制并发ping数量。
     */
    bool pingHost(const QString& ipAddress, int timeoutMs = 1500);
};

#endif // NETWORKSCANNER_H 